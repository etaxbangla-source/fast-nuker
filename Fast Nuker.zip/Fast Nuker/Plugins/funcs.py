# Plugins/funcs.py

from colorama import Fore, Style
import os
import asyncio
from Plugins.logger import Logger
import re
import threading
import time
import inspect
import random # Import random for jitter

class Funcs:
    @staticmethod
    def _apply_multi_color_gradient_internal(text: str, color_list: list) -> str:
        """
        Takes a string and a list of colorama color codes and applies a gradient
        to the text, character by character, cycling through the colors.
        """
        if not text:
            return ""
        if not color_list:
            return text

        colored_chars = []
        num_colors = len(color_list)
        text_length = len(text)

        for i, char in enumerate(text):
            if text_length <= 1: # Handle single character or empty string gracefully
                color_index = 0
            else:
                # Distribute colors evenly across the text
                color_index = min(int(i / text_length * num_colors), num_colors - 1)
            
            colored_chars.append(f"{color_list[color_index]}{char}{Logger.RESET}")
        
        return "".join(colored_chars)

    @staticmethod
    def _create_gradient_line(length: int, colors: list, char: str = '═') -> str:
        """
        Creates a horizontal line with a gradient effect, suitable for borders.
        """
        if not colors:
            return char * length # Fallback if no colors provided
        
        gradient_chars = []
        num_colors = len(colors)
        for i in range(length):
            color_index = min(int(i / length * num_colors), num_colors - 1)
            gradient_chars.append(f"{colors[color_index]}{char}{Logger.RESET}")
        return "".join(gradient_chars)

    @staticmethod
    def center_text(text: str, width: int) -> str:
        """
        Centers text within a given width, accounting for ANSI escape codes.
        """
        # Remove ANSI escape codes to calculate the visible length
        visible_length = len(re.sub(r'\x1b\[[0-9;]*m', '', text))
        padding = (width - visible_length) // 2
        return " " * max(0, padding) + text

    @staticmethod
    async def get_input(prompt: str, checker) -> str:
        """
        Asynchronously gets user input, validating it with a provided checker function.
        Handles both sync and async checker functions.
        """
        while True:
            try:
                # Apply an even more intense glow to the prompt
                colored_prompt_suffix = Logger._apply_glow(prompt, intense=True)
                
                # FIX: Directly await asyncio.to_thread for input
                response = await asyncio.to_thread(input, colored_prompt_suffix)
                response = response.strip()

                # Conditionally await the checker function
                if inspect.iscoroutinefunction(checker):
                    # FIX: Directly await the checker function
                    is_valid = await checker(response)
                else:
                    is_valid = checker(response)

                if is_valid:
                    return response
                else:
                    print(f"{Logger.WARNING_YELLOW}[!] Invalid input. Please try again.{Logger.RESET}")
            except KeyboardInterrupt:
                print(f"\n{Logger.WARNING_YELLOW}[!] Operation cancelled by user.{Logger.RESET}")
                return None
            except EOFError:
                print(f"\n{Logger.ERROR_RED}[×] End of input reached.{Logger.RESET}")
                return None

    @staticmethod
    def print_logo():
        """
        Prints the "BERSERK" ASCII art logo with a dynamic, glowing color mixture gradient
        and aesthetic top/bottom banners.
        """
        os.system('cls' if os.name == 'nt' else 'clear')

        terminal_width = os.get_terminal_size().columns

        # Refined gradient palette for a more "mixed" and glowing effect (blue, pink, purple focus)
        logo_gradient_colors = [
            Logger.ELECTRIC_PURPLE, Logger.GLOW_PURPLE, Logger.NEON_PINK,
            Logger.HOT_PINK, Logger.ROYAL_BLUE, Logger.ELECTRIC_BLUE,
            Logger.GLOW_BLUE, Logger.ELECTRIC_PURPLE, Logger.NEON_PINK
        ]

        # BERSERK ASCII art (as provided by the user)
        berserk_only_art_lines = [
            
          ":::!~!!!",                  
            "                      .xUHWH!! !!?M88WHX:.",            
            "                    .X*#M@$!!  !X!M$$$$$$WWx:.",          
            "                   :!!!!!!?H! :!$!$$$$$$$$$$8X:",        
            "                  !!~  ~:~!! :~!$!#$$$$$$$$$$8X:",      
            "                 :!~::!H!<   ~.U$X!?R$$$$$$$$MM!",        
            "                 ~!~!!!!~~ .:XW$$$U!!?$$$$$$RMM!",      
            "                   !:~~~ .:!M\"T#$$$$WX??#MRRMMM!",     
            "                   ~?WuxiW*`   `\"#$$$$8!!!!??!!!",       
            "                 :X- M$$$$       `\"T#$T~!8$WUXU~",     
            "                :%`  ~#$$$m:        ~!~ ?$$$$$$",     
            "              :!`.--   ~T$$$$8xx.  .xWW- ~\"\"##*\"",       
            "        .....   -~~:<` !    ~?T#$$@@W@*?$$      /`",     
            "        W$@@M!!! .!~~ !!     .:XUW$W!~ `\"~:    $ :",     
            "        #\"~~`.:x%`!!  !H:   !WM$$$$Ti.: .!WUn+!`",  
            "        :::~:!!`:X~ .: ?H.!u \"$$$B$$$!W:U!T$$M~", 
            "        .~~   :X@!.-~   ?@WTWo(\"*$$$W$TH$! `",    
            "        Wi.~!X$?!-~    : ?$$$B$Wu(\"**$RM!",       
            "        $R@ i.~~ !     :   ~$$$$$B$$en:``",      
            "        ?MXT@Wx.~    :    ~\"##*$$$$M~"
        
        ]

        # Apply character-by-character gradient to the logo lines
        colored_logo_art = [
            Funcs._apply_multi_color_gradient_internal(line, logo_gradient_colors) for line in berserk_only_art_lines
        ]

        # Enhanced Top Banner with a complex, mixed gradient and subtle pattern
        top_banner_text = "   R A J JIJA OWNS U   "
        banner_gradient_colors = [
            Logger.ELECTRIC_BLUE, Logger.GLOW_BLUE, Logger.ROYAL_BLUE,
            Logger.GLOW_PURPLE, Logger.ELECTRIC_PURPLE, Logger.NEON_PINK,
            Logger.ROYAL_BLUE, Logger.ELECTRIC_BLUE # Return for a blend effect
        ]
        
        # More aesthetic banner pattern
        banner_pattern_left = f"{Logger.ELECTRIC_BLUE}━{Logger.ROYAL_BLUE}═{Logger.GLOW_PURPLE}─" * 4
        banner_pattern_right = f"{Logger.GLOW_PURPLE}─{Logger.ROYAL_BLUE}═{Logger.ELECTRIC_BLUE}━" * 4
        
        # Using the internal helper for banner content
        top_banner_content = Funcs._apply_multi_color_gradient_internal(top_banner_text, banner_gradient_colors)
        top_banner_full = f"{banner_pattern_left}{Logger.GLOW_BLUE} {top_banner_content} {banner_pattern_right}{Logger.RESET}"
        
        print(Funcs.center_text(top_banner_full, terminal_width))
        print("\n") # More vertical spacing for impact

        # Print the gradient-applied logo
        for line in colored_logo_art:
            print(Funcs.center_text(line, terminal_width))
        
        print("\n") # More vertical spacing

        # Enhanced Bottom Banner matching the top banner's style with reversed mixed gradient
        bottom_banner_text = "   R A J JIJA RULES CORD   "
        # Using the internal helper for banner content
        bottom_banner_content = Funcs._apply_multi_color_gradient_internal(bottom_banner_text, list(reversed(banner_gradient_colors))) # Reversed gradient for flow
        bottom_banner_full = f"{banner_pattern_left}{Logger.GLOW_BLUE} {bottom_banner_content} {banner_pattern_right}{Logger.RESET}"
        
        print(Funcs.center_text(bottom_banner_full, terminal_width))
        print("\n")


    @staticmethod
    def print_help_menu(info: dict):
        """
        Prints a simplified help menu with Discord server and user info,
        using basic colors and a clean single-column layout without gradients.
        """
        Funcs.print_logo()

        # Simplified colors for the menu
        category_color = Fore.MAGENTA
        option_number_color = Fore.CYAN
        option_name_color = Fore.WHITE
        info_label_color = Fore.YELLOW
        info_value_color = Fore.GREEN
        border_color = Fore.BLUE
        reset = Style.RESET_ALL

        menu_options = {
            "CHANNEL MANAGEMENT": [
                ("01", "Delete All Channels"),
                ("05", "Mass Create Channels"),
                ("10", "Rename All Channels"),
                ("23", "Change Channel Topic")
            ],
            "ROLE MANAGEMENT": [
                ("02", "Delete All Roles"),
                ("06", "Mass Create Roles"),
                ("11", "Rename All Roles")
            ],
            "MEMBER MANAGEMENT": [
                ("03", "Mass Ban Members"),
                ("04", "Mass Kick Members"),
                ("07", "Unban All Members"),
                ("12", "Nick All Users"),
                ("13", "UnNick All Users"),
                ("19", "Timeout All Members"),
                ("20", "Prune Members"),
                ("21", "Give Admin Role"),
                ("25", "Ban All Bots")
            ],
            "GUILD MANAGEMENT": [
                ("14", "Change Guild Name"),
                ("15", "Change Guild Icon"),
                ("16", "Remove All Emojis"),
                ("22", "Vanity URL Changer"),
                ("24", "Change Server Info"),
                ("26", "Server Emoji Rename")
            ],
            "SPAMMING & MESSAGING": [
                ("08", "Webhook Spam Guild"),
                ("09", "Message Spam Guild"),
                ("17", "DM All Members")
            ],
            "ADVANCED OPERATIONS": [
                ("18", "NUKE (Destroy/Bypass)")
            ],
            "UTILITIES": [
                ("28", "CHANGE SERVER/GUILD") 
            ],
            "EXIT": [
                ("27", "Exit Program")
            ]
        }

        terminal_width = os.get_terminal_size().columns

        # Calculate max width for cleaner formatting
        max_content_width = 0
        for category, options in menu_options.items():
            max_content_width = max(max_content_width, len(category) + 4) # For category name
            for num, name in options:
                max_content_width = max(max_content_width, len(f"{num}. {name}") + 4) # For option line
        
        # Determine width for info box based on its content
        max_info_line_length = 0
        if isinstance(info, dict) and 'user' in info:
            guild_data = info.get('guild', {})
            guild_name = guild_data.get('name', 'N/A')
            guild_id = guild_data.get('id', 'N/A')
            guild_members = guild_data.get('members', 'N/A')
            user_name = info['user'].get('username', 'N/A')
            user_discriminator = info['user'].get('discriminator', 'N/A')
            user_id = info['user'].get('id', 'N/A')

            max_info_line_length = max(
                len(f"SERVER: {guild_name}"),
                len(f"GUILD ID: {guild_id}"),
                len(f"MEMBERS: {guild_members}"),
                len(f"BOT USER: {user_name}#{user_discriminator}"),
                len(f"USER ID: {user_id}")
            )
        else:
            max_info_line_length = len("SERVER/USER INFO: N/A (Data not provided)")

        # The overall box width will be determined by the widest element plus padding
        menu_box_width = max(max_content_width, max_info_line_length + 4) + 4 # +4 for outer padding/borders

        def create_simple_line(length: int, color: str, char: str = '═') -> str:
            return f"{color}{char * length}{reset}"

        def get_padded_line(text, target_width):
            visible_len = len(re.sub(r'\x1b\[[0-9;]*m', '', text))
            padding = max(0, target_width - visible_len)
            return text + " " * padding

        # Server and User Information Display
        print(Funcs.center_text(f"{border_color}╔{create_simple_line(menu_box_width - 2, border_color)}╗{reset}", terminal_width))
        print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}SERVER/USER INFORMATION{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
        print(Funcs.center_text(f"{border_color}╠{create_simple_line(menu_box_width - 2, border_color)}╣{reset}", terminal_width))

        if isinstance(info, dict) and 'user' in info:
            guild_data = info.get('guild', {})
            guild_name = guild_data.get('name', 'N/A')
            guild_id = guild_data.get('id', 'N/A')
            guild_members = guild_data.get('members', 'N/A')

            user_name = info['user'].get('username', 'N/A')
            user_discriminator = info['user'].get('discriminator', 'N/A')
            user_id = info['user'].get('id', 'N/A')

            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}SERVER:{reset} {info_value_color}{guild_name}{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}GUILD ID:{reset} {info_value_color}{guild_id}{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}MEMBERS:{reset} {info_value_color}{guild_members}{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}BOT USER:{reset} {info_value_color}{user_name}#{user_discriminator}{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}USER ID:{reset} {info_value_color}{user_id}{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
        else:
            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{info_label_color}SERVER/USER INFO:{reset} {info_value_color}N/A (Data not provided){reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
        
        print(Funcs.center_text(f"{border_color}╚{create_simple_line(menu_box_width - 2, border_color)}╝{reset}", terminal_width))
        print("\n")

        # Menu Options Display
        print(Funcs.center_text(f"{border_color}╔{create_simple_line(menu_box_width - 2, border_color)}╗{reset}", terminal_width))
        print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{Fore.CYAN}>>> SELECT AN OPTION <<< {reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
        print(Funcs.center_text(f"{border_color}╠{create_simple_line(menu_box_width - 2, border_color)}╣{reset}", terminal_width))

        for category, options in menu_options.items():
            print(Funcs.center_text(f"{border_color}║ {get_padded_line(f'{category_color}{category}{reset}', menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
            print(Funcs.center_text(f"{border_color}╟{create_simple_line(menu_box_width - 2, border_color)}╢{reset}", terminal_width))

            for num, name in options:
                option_str = f"{option_number_color}{num}.{reset} {option_name_color}{name}{reset}"
                print(Funcs.center_text(f"{border_color}║ {get_padded_line(option_str, menu_box_width - 4)}{border_color} ║{reset}", terminal_width))
            
            if category != "EXIT":
                print(Funcs.center_text(f"{border_color}╠{create_simple_line(menu_box_width - 2, border_color)}╣{reset}", terminal_width))

        print(Funcs.center_text(f"{border_color}╚{create_simple_line(menu_box_width - 2, border_color)}╝{reset}", terminal_width))
        print("\n")


    @staticmethod
    def show_loading_animation(message="Processing"):
        """Display a loading animation with dynamically changing glow colors for the spinner."""
        
        stop_animation = threading.Event()
        
        def animate():
            spin_chars = ["|", "/", "-", "\\"] 
            spinner_colors = [
                Logger.ELECTRIC_CYAN, Logger.GLOW_BLUE, Logger.ELECTRIC_PURPLE,
                Logger.NEON_PINK, Logger.GOLDEN_GLOW, Logger.NEON_GREEN
            ]
            char_idx = 0
            color_idx = 0
            while not stop_animation.is_set():
                char = spin_chars[char_idx % len(spin_chars)]
                current_spinner_color = spinner_colors[color_idx % len(spinner_colors)]
                
                glowing_char = Logger._apply_glow(char, intense=True)
                full_message_text = f"{glowing_char} {message}..."
                
                message_gradient = Funcs._apply_multi_color_gradient_internal(full_message_text, [Logger.GLOW_BLUE, Logger.GLOW_PURPLE, Logger.ROYAL_BLUE])
                
                print(f"\r{Funcs.center_text(message_gradient, os.get_terminal_size().columns)}", end='', flush=True)
                time.sleep(0.1)
                char_idx += 1
                color_idx += 1
            print(f"\r{' ' * os.get_terminal_size().columns}\r", end='', flush=True) # Clear line

        animation_thread = threading.Thread(target=animate)
        animation_thread.daemon = True
        animation_thread.start()
        
        return stop_animation

    @staticmethod
    def display_ascii_art():
        """Display a generic enhanced visual system active banner with a mixed gradient."""
        terminal_width = os.get_terminal_size().columns
        
        border_pattern = f"{Logger.NEON_PINK}═{Logger.HOT_PINK}━{Logger.FIRE_ORANGE}─" * 5
        top_border = f"{border_pattern}{Logger.GOLDEN_GLOW}{'═' * (terminal_width - len(border_pattern) * 2)}{border_pattern}{Logger.RESET}"
        bottom_border = f"{border_pattern}{Logger.GOLDEN_GLOW}{'═' * (terminal_width - len(border_pattern) * 2)}{border_pattern}{Logger.RESET}"
        
        message_gradient_colors = [
            Logger.NEON_GREEN, Logger.ELECTRIC_CYAN, Logger.ELECTRIC_BLUE,
            Logger.ROYAL_BLUE, Logger.GLOW_PURPLE, Logger.ELECTRIC_PURPLE
        ]
        message = Funcs._apply_multi_color_gradient_internal("  ENHANCED VISUAL SYSTEM ACTIVE  ", message_gradient_colors)
        
        print(top_border)
        print(Funcs.center_text(message, terminal_width))
        print(bottom_border)
        print(Logger.RESET)

# Define a specific gradient for tqdm bars to be used in main.py
Funcs.tqdm_bar_gradient_colors = [
    Logger.ELECTRIC_BLUE, Logger.GLOW_BLUE, Logger.GLOW_PURPLE, Logger.NEON_PINK
]