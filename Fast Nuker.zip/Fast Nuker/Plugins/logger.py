from colorama import Fore, Style, Back
from pystyle import Colors, Colorate, Col
import aiofiles
import asyncio
from datetime import datetime
from typing import Any


class Logger:
    # Enhanced color definitions with precise RGB values and glowing effects
    ROYAL_BLUE = "\033[38;2;65;105;225m"
    DEEP_PURPLE = "\033[38;2;75;0;130m"
    GLOW_PURPLE = "\033[38;2;147;112;219m"
    GLOW_BLUE = "\033[38;2;100;149;237m"
    ELECTRIC_PURPLE = "\033[38;2;138;43;226m"
    ELECTRIC_BLUE = "\033[38;2;30;144;255m"
    NEON_PINK = "\033[38;2;255;20;147m"
    NEON_GREEN = "\033[38;2;57;255;20m"
    ELECTRIC_CYAN = "\033[38;2;0;255;255m"
    GOLDEN_GLOW = "\033[38;2;255;215;0m"
    FIRE_ORANGE = "\033[38;2;255;69;0m"
    HOT_PINK = "\033[38;2;255;105;180m"
    
    # Status colors with enhanced visibility
    ERROR_RED = "\033[38;2;255;59;48m"
    SUCCESS_GREEN = "\033[38;2;57;255;20m"
    WARNING_YELLOW = "\033[38;2;255;255;20m"
    INFO_CYAN = "\033[38;2;0;255;255m"
    
    # Background colors for special effects
    BG_DARK = "\033[48;2;25;25;25m"
    BG_PURPLE = "\033[48;2;75;0;130m"
    BG_BLUE = "\033[48;2;0;0;139m"
    
    RESET = Style.RESET_ALL
    BOLD = Style.BRIGHT
    DIM = Style.DIM

    @staticmethod
    def _create_border(length: int = 60) -> str:
        """Create a glowing border with gradient effect"""
        border_chars = "◆◇◆◇◆◇◆◇◆◇" * (length // 10 + 1)
        return f"{Logger.GLOW_PURPLE}{border_chars[:length]}{Logger.RESET}"

    @staticmethod
    def _apply_glow(text: str, intense: bool = False) -> str:
        """Apply enhanced purple and blue glow effect to text"""
        if intense:
            return (
                f"{Logger.ELECTRIC_PURPLE}◆{Logger.ELECTRIC_BLUE}◇{Logger.NEON_PINK}◆{Logger.RESET} "
                f"{Logger.BOLD}{text}{Logger.RESET} "
                f"{Logger.NEON_PINK}◆{Logger.ELECTRIC_BLUE}◇{Logger.ELECTRIC_PURPLE}◆{Logger.RESET}"
            )
        else:
            return (
                f"{Logger.GLOW_PURPLE}◆{Logger.GLOW_BLUE}◇{Logger.RESET} "
                f"{text} "
                f"{Logger.GLOW_BLUE}◇{Logger.GLOW_PURPLE}◆{Logger.RESET}"
            )

    @staticmethod
    def _apply_rainbow_glow(text: str) -> str:
        """Apply rainbow glow effect for special occasions"""
        return (
            f"{Logger.NEON_PINK}◆{Logger.ELECTRIC_CYAN}◇{Logger.NEON_GREEN}◆{Logger.GOLDEN_GLOW}◇{Logger.FIRE_ORANGE}◆{Logger.RESET} "
            f"{Logger.BOLD}{text}{Logger.RESET} "
            f"{Logger.FIRE_ORANGE}◆{Logger.GOLDEN_GLOW}◇{Logger.NEON_GREEN}◆{Logger.ELECTRIC_CYAN}◇{Logger.NEON_PINK}◆{Logger.RESET}"
        )

    @staticmethod
    def _gradient_text(text: str, color1: str, color2: str) -> str:
        """Create gradient text effect"""
        result = ""
        length = len(text)
        for i, char in enumerate(text):
            ratio = i / length if length > 1 else 0
            current_color = color1 if ratio < 0.5 else color2
            result += f"{current_color}{char}"
        return result + Logger.RESET

    class Success:
        @staticmethod
        async def create(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[+] Created {value}", Logger.SUCCESS_GREEN, Logger.ELECTRIC_CYAN)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"SUCCESS: Created {value}")

        @staticmethod
        async def delete(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[+] Deleted {value}", Logger.SUCCESS_GREEN, Logger.ELECTRIC_CYAN)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"SUCCESS: Deleted {value}")

        @staticmethod
        async def change(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[~] Changed {value}", Logger.WARNING_YELLOW, Logger.GOLDEN_GLOW)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"SUCCESS: Changed {value}")

        @staticmethod
        async def success(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[✓] {value}", Logger.SUCCESS_GREEN, Logger.NEON_GREEN)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"SUCCESS: {value}")

        @staticmethod
        async def nuke_complete() -> None:
            msg = Logger._apply_rainbow_glow("NUKE OPERATION COMPLETED SUCCESSFULLY")
            print(f"\n{Logger._create_border()}")
            print(f"{msg}")
            print(f"{Logger._create_border()}\n")
            await Logger._log_to_file("NUKE OPERATION COMPLETED")

    class Error:
        @staticmethod
        async def create(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[×] Failed to Create {value}", Logger.ERROR_RED, Logger.FIRE_ORANGE)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"ERROR: Failed to Create {value}")

        @staticmethod
        async def delete(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[×] Failed to Delete {value}", Logger.ERROR_RED, Logger.FIRE_ORANGE)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"ERROR: Failed to Delete {value}")

        @staticmethod
        async def change(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[×] Failed to Change {value}", Logger.ERROR_RED, Logger.FIRE_ORANGE)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"ERROR: Failed to Change {value}")

        @staticmethod
        async def error(value: Any) -> None:
            gradient_text = Logger._gradient_text(f"[!] {value}", Logger.ERROR_RED, Logger.HOT_PINK)
            msg = Logger._apply_glow(gradient_text, intense=True)
            print(msg)
            await Logger._log_to_file(f"ERROR: {value}")

        @staticmethod
        async def critical(value: Any) -> None:
            msg = Logger._apply_rainbow_glow(f"CRITICAL ERROR: {value}")
            print(f"\n{Logger._create_border()}")
            print(f"{msg}")
            print(f"{Logger._create_border()}\n")
            await Logger._log_to_file(f"CRITICAL ERROR: {value}")

    class Log:
        @staticmethod
        async def started() -> None:
            # Enhanced status message
            status_msg = Logger._gradient_text("SYSTEM INITIALIZED - READY FOR OPERATIONS", Logger.SUCCESS_GREEN, Logger.ELECTRIC_CYAN)
            print(Logger._apply_glow(status_msg, intense=True))
            print()
            
            await Logger._log_to_file("=== SESSION STARTED ===")

        @staticmethod
        async def warning(message: str) -> None:
            gradient_text = Logger._gradient_text(f"[!] {message}", Logger.WARNING_YELLOW, Logger.GOLDEN_GLOW)
            msg = Logger._apply_glow(gradient_text)
            print(msg)
            await Logger._log_to_file(f"WARNING: {message}")

        @staticmethod
        async def info(message: str) -> None:
            gradient_text = Logger._gradient_text(f"[i] {message}", Logger.INFO_CYAN, Logger.ELECTRIC_BLUE)
            msg = Logger._apply_glow(gradient_text)
            print(msg)
            await Logger._log_to_file(f"INFO: {message}")

        @staticmethod
        async def debug(message: str) -> None:
            gradient_text = Logger._gradient_text(f"[DEBUG] {message}", Logger.GLOW_PURPLE, Logger.ELECTRIC_PURPLE)
            msg = Logger._apply_glow(gradient_text)
            print(msg)
            await Logger._log_to_file(f"DEBUG: {message}")

    @staticmethod
    async def _log_to_file(message: str) -> None:
        """Enhanced async log to file with timestamp and formatting"""
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            async with aiofiles.open('discord_tool.log', mode='a', encoding='utf-8') as f:
                await f.write(f"[{timestamp}] {message}\n")
        except Exception as e:
            error_msg = f"{Logger.ERROR_RED}Failed to write to log file: {e}{Logger.RESET}"
            print(Logger._apply_glow(error_msg, intense=True))

    @staticmethod
    def print_color_test():
        """Display all available colors for testing"""
        print(f"{Logger._create_border()}")
        print(Logger._apply_glow("COLOR PALETTE TEST", intense=True))
        print(f"{Logger._create_border()}")
        
        colors = [
            (Logger.ROYAL_BLUE, "ROYAL BLUE"),
            (Logger.DEEP_PURPLE, "DEEP PURPLE"),
            (Logger.GLOW_PURPLE, "GLOW PURPLE"),
            (Logger.GLOW_BLUE, "GLOW BLUE"),
            (Logger.ELECTRIC_PURPLE, "ELECTRIC PURPLE"),
            (Logger.ELECTRIC_BLUE, "ELECTRIC BLUE"),
            (Logger.NEON_PINK, "NEON PINK"),
            (Logger.NEON_GREEN, "NEON GREEN"),
            (Logger.ELECTRIC_CYAN, "ELECTRIC CYAN"),
            (Logger.GOLDEN_GLOW, "GOLDEN GLOW"),
            (Logger.FIRE_ORANGE, "FIRE ORANGE"),
            (Logger.HOT_PINK, "HOT PINK"),
        ]
        
        for color, name in colors:
            colored_text = f"{color}{name}{Logger.RESET}"
            print(f"  {Logger._apply_glow(colored_text)}")
        
        print(f"{Logger._create_border()}")
