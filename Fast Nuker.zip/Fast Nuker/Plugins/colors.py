class Palette:
    def __init__(self) -> None:
        # Enhanced color palette with RGB precision and glow effects
        self.colors = [
            # Base colors with enhanced definitions
            '\x1b[1;97m',           # Bright white
            '\x1b[1;91m',           # Bright red
            '\x1b[1;92m',           # Bright green
            '\x1b[1;93m',           # Bright yellow
            '\x1b[1;94m',           # Bright blue
            '\x1b[1;95m',           # Bright magenta
            '\x1b[1;96m',           # Bright cyan
            '\x1b[0m',              # Reset
            
            # Enhanced RGB colors for glowing effects
            '\x1b[38;2;147;112;219m',  # Medium slate blue (glow purple)
            '\x1b[38;2;100;149;237m',  # Cornflower blue (glow blue)
            '\x1b[38;2;255;20;147m',   # Deep pink (neon pink)
            '\x1b[38;2;0;255;255m',    # Cyan (electric cyan)
            '\x1b[38;2;255;215;0m',    # Gold (golden glow)
            '\x1b[38;2;50;205;50m',    # Lime green (neon green)
            '\x1b[38;2;255;69;0m',     # Orange red (fire orange)
            '\x1b[38;2;138;43;226m',   # Blue violet (electric purple)
            
            # Dark theme colors
            '\x1b[38;2;25;25;25m',     # Dark gray
            '\x1b[38;2;45;45;45m',     # Medium dark gray
            '\x1b[38;2;75;0;130m',     # Indigo (deep purple)
            '\x1b[38;2;65;105;225m',   # Royal blue
            
            # Gradient effect colors
            '\x1b[38;2;255;0;255m',    # Magenta (electric magenta)
            '\x1b[38;2;0;255;0m',      # Lime (electric lime)
            '\x1b[38;2;255;165;0m',    # Orange (warm orange)
            '\x1b[38;2;255;105;180m',  # Hot pink (vibrant pink)
            '\x1b[38;2;30;144;255m',   # Dodger blue (electric blue)
            '\x1b[38;2;255;20;147m',   # Deep pink (neon pink)
            
            # Special effect colors
            '\x1b[38;2;255;255;255m',  # Pure white
            '\x1b[38;2;0;0;0m',        # Pure black
            '\x1b[38;2;128;0;128m',    # Purple
            '\x1b[38;2;255;192;203m',  # Pink
            '\x1b[38;2;173;216;230m',  # Light blue
            '\x1b[38;2;144;238;144m',  # Light green
            
            # Glowing border colors
            '\x1b[38;2;186;85;211m',   # Medium orchid
            '\x1b[38;2;72;61;139m',    # Dark slate blue
            '\x1b[38;2;123;104;238m',  # Medium slate blue
            '\x1b[38;2;148;0;211m',    # Dark violet
            '\x1b[38;2;199;21;133m',   # Medium violet red
            
            # Neon glow effects
            '\x1b[38;2;57;255;20m',    # Neon green
            '\x1b[38;2;255;20;147m',   # Neon pink
            '\x1b[38;2;20;255;255m',   # Neon cyan
            '\x1b[38;2;255;255;20m',   # Neon yellow
            '\x1b[38;2;255;20;20m',    # Neon red
            '\x1b[38;2;147;20;255m',   # Neon purple
            
            # Gradient transition colors
            '\x1b[38;2;255;0;128m',    # Rose
            '\x1b[38;2;128;0;255m',    # Violet
            '\x1b[38;2;0;128;255m',    # Sky blue
            '\x1b[38;2;0;255;128m',    # Spring green
            '\x1b[38;2;128;255;0m',    # Lime yellow
            '\x1b[38;2;255;128;0m',    # Orange
        ]

    # Enhanced property methods with glowing effects
    @property
    def error(self):
        return '\x1b[41m\x1b[1;97m'  # Red background with white text
    
    @property
    def neon_pink(self):
        return '\x1b[38;2;255;20;147m'
    
    @property
    def electric_cyan(self):
        return '\x1b[38;2;0;255;255m'
    
    @property
    def glow_purple(self):
        return '\x1b[38;2;147;112;219m'
    
    @property
    def glow_blue(self):
        return '\x1b[38;2;100;149;237m'
    
    @property
    def electric_green(self):
        return '\x1b[38;2;57;255;20m'
    
    @property
    def fire_orange(self):
        return '\x1b[38;2;255;69;0m'
    
    @property
    def golden_glow(self):
        return '\x1b[38;2;255;215;0m'
    
    @property
    def deep_purple(self):
        return '\x1b[38;2;75;0;130m'
    
    @property
    def royal_blue(self):
        return '\x1b[38;2;65;105;225m'
    
    @property
    def sky_blue(self):
        return self.colors[6]
    
    @property
    def red(self):
        return self.colors[1]
    
    @property
    def magenta(self):
        return '\x1b[38;2;255;0;255m'
    
    @property
    def sexy_blue(self):
        return '\x1b[38;2;30;144;255m'

    @property
    def grassy_green(self):
        return '\x1b[38;2;50;205;50m'

    @property
    def sunny_yellow(self):
        return '\x1b[38;2;255;255;20m'

    @property
    def fucked_up_blue(self):
        return '\x1b[38;2;0;128;255m'

    @property
    def better_grassy_green(self):
        return '\x1b[38;2;0;255;128m'
    
    @property
    def mustard(self):
        return '\x1b[38;2;255;219;88m'
    
    @property
    def grey(self):
        return '\x1b[38;2;128;128;128m'
    
    @property
    def better_purple(self):
        return '\x1b[38;2;138;43;226m'

    @property
    def reset(self):
        return "\033[0m"

    @property
    def electric_purple(self):
        return '\x1b[38;2;138;43;226m'

    @property
    def neon_green(self):
        return '\x1b[38;2;57;255;20m'

    @property
    def hot_pink(self):
        return '\x1b[38;2;255;105;180m'

    @property
    def electric_blue(self):
        return '\x1b[38;2;30;144;255m'

    def create_gradient(self, text, color1, color2):
        """Create a gradient effect between two colors"""
        gradient_text = ""
        length = len(text)
        for i, char in enumerate(text):
            # Simple gradient calculation
            ratio = i / length if length > 1 else 0
            gradient_text += f"{color1 if ratio < 0.5 else color2}{char}"
        return gradient_text + self.reset

    def add_glow(self, text, color):
        """Add glowing effect to text"""
        return f"{color}◆◇{self.reset} {color}{text}{self.reset} {color}◇◆{self.reset}"

    def print_all(self):
        """Display all available colors with enhanced formatting"""
        print(f"{self.glow_purple}╔══════════════════════════════════════════════════════════════╗{self.reset}")
        print(f"{self.glow_purple}║{self.glow_blue}                    ENHANCED COLOR PALETTE                    {self.glow_purple}║{self.reset}")
        print(f"{self.glow_purple}╚══════════════════════════════════════════════════════════════╝{self.reset}")
        
        for i in range(len(self.colors)):
            glow_text = self.add_glow(f"Color {i:2d}: Hello World!", self.colors[i])
            print(f"  {glow_text}")

    def print_gradient_demo(self):
        """Demonstrate gradient effects"""
        print(f"{self.glow_purple}╔══════════════════════════════════════════════════════════════╗{self.reset}")
        print(f"{self.glow_purple}║{self.glow_blue}                    GRADIENT EFFECTS DEMO                    {self.glow_purple}║{self.reset}")
        print(f"{self.glow_purple}╚══════════════════════════════════════════════════════════════╝{self.reset}")
        
        # Demonstrate various gradient combinations
        gradients = [
            (self.neon_pink, self.electric_cyan, "NEON PINK → ELECTRIC CYAN"),
            (self.glow_purple, self.glow_blue, "GLOW PURPLE → GLOW BLUE"),
            (self.electric_green, self.golden_glow, "ELECTRIC GREEN → GOLDEN GLOW"),
            (self.fire_orange, self.hot_pink, "FIRE ORANGE → HOT PINK"),
        ]
        
        for color1, color2, desc in gradients:
            gradient_text = self.create_gradient("█████████████████████████████████████████", color1, color2)
            print(f"  {gradient_text} {self.glow_blue}{desc}{self.reset}")


# Create a global instance for easy access
my_palette = Palette()
