import aiohttp
import asyncio
import random
import os
from typing import List, Tuple, Optional, Dict, Any
from concurrent.futures import ThreadPoolExecutor

class Tools:
    _executor = ThreadPoolExecutor(max_workers=50)
    _session = None  # Will be initialized on first use

    @classmethod
    async def get_session(cls) -> aiohttp.ClientSession:
        """Get or create a shared aiohttp session"""
        if cls._session is None or cls._session.closed:
            connector = aiohttp.TCPConnector(limit=200, force_close=True)
            timeout = aiohttp.ClientTimeout(total=30)
            cls._session = aiohttp.ClientSession(connector=connector, timeout=timeout)
        return cls._session

    @classmethod
    async def close_session(cls) -> None:
        """Close the shared session"""
        if cls._session and not cls._session.closed:
            await cls._session.close()
            cls._session = None

    @staticmethod
    async def check_token(token: str) -> bool:
        """Async token validation"""
        session = await Tools.get_session()
        try:
            async with session.get(
                "https://discord.com/api/v10/users/@me",
                headers={"Authorization": f"Bot {token}"}
            ) as response:
                return response.status == 200
        except Exception:
            return False

    @staticmethod
    async def get_guilds(token: str) -> List[Tuple[str, str]]:
        """Async guild fetching"""
        session = await Tools.get_session()
        try:
            async with session.get(
                Tools.api("users/@me/guilds"),
                headers={"Authorization": f"Bot {token}", "Content-Type": "application/json"}
            ) as response:
                if response.status != 200:
                    return []
                guilds = await response.json()
                return [(g["id"], g["name"]) for g in guilds]
        except Exception:
            return []

    @staticmethod
    def proxy() -> Optional[Dict[str, str]]:
        """Sync proxy handling (for aiohttp compatibility)"""
        if os.path.exists("./proxies.txt"):
            with open("./proxies.txt", "r") as file:
                lines = [line.strip() for line in file if line.strip()]
                if lines:
                    proxy = random.choice(lines)
                    return {"http": proxy, "https": proxy}
        return None

    @staticmethod
    def api(endpoint: str) -> str:
        """API endpoint builder"""
        base_api = "https://discord.com/api/v10/"
        if endpoint.startswith("/"):
            endpoint = endpoint[1:]
        return base_api + endpoint

    @staticmethod
    async def break_limit(session: aiohttp.ClientSession, base_api: str, token: str, chunk_size: int = 1000) -> List[str]:
        """Async pagination handler"""
        users = []
        after = None
        
        while True:
            params = {"limit": str(chunk_size)}
            if after:
                params["after"] = after
                
            try:
                async with session.get(
                    base_api,
                    params=params,
                    headers={"Authorization": f"Bot {token}"}
                ) as response:
                    if response.status != 200:
                        break
                        
                    data = await response.json()
                    if not data:
                        break
                        
                    try:
                        new_users = [i["user"]["id"] for i in data]
                    except KeyError:
                        new_users = [i["id"] for i in data]
                        
                    users.extend(new_users)
                    after = users[-1] if users else None
                    
                    if len(new_users) < chunk_size:
                        break
            except Exception:
                break
                
        return users

    @staticmethod
    def chunker(text: str, chunk_size: int) -> List[str]:
        """Text chunking utility"""
        return [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]

    @staticmethod
    async def information(guild_id: str, token: str) -> Dict[str, Any]:
        """Async guild information fetcher"""
        session = await Tools.get_session()
        try:
            # Get user info
            async with session.get(
                Tools.api("users/@me"),
                headers={"Authorization": f"Bot {token}"}
            ) as user_response:
                user_data = await user_response.json() if user_response.status == 200 else {}

            # Get guild info
            async with session.get(
                Tools.api(f"/guilds/{guild_id}"),
                headers={"Authorization": f"Bot {token}"}
            ) as guild_response:
                guild_data = await guild_response.json() if guild_response.status == 200 else {}

            return {
                "user": user_data,
                "guild": guild_data
            }
        except Exception:
            return {
                "user": {"username": "Unknown", "id": "0"},
                "guild": {"name": "Unknown Guild", "id": "0"}
            }

    @classmethod
    async def cleanup(cls) -> None:
        """Clean up resources"""
        await cls.close_session()
        cls._executor.shutdown(wait=False)